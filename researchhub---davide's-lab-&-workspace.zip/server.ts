import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Initialize Gemini Client
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is not configured");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// API: Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// API: AI Agent interaction endpoint
app.post("/api/agent", async (req, res) => {
  try {
    const { prompt, context } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    const ai = getGeminiClient();

    const systemInstruction = `Sei l'assistente AI personale di Davide, un PhD Researcher specializzato in gene e cell therapy (editing genico, RFXANK/MHC-II, VUS leucemia, HSC biology, prime editing, CRISPR).
Il tuo obiettivo è aiutarlo a gestire la sua vita quotidiana e le sue attività di laboratorio senza perdite di tempo.

Rispondi SEMPRE in italiano, con tono professionale, chiaro, conciso e incoraggiante.

Hai accesso al contesto attuale dei dati di Davide:
${JSON.stringify(context || {}, null, 2)}

Quando rispondi a domande su cosa ha in agenda, task in scadenza, riassunti di note o paper salvati, usa le informazioni fornite nel contesto.

Inoltre, se la richiesta dell'utente implica la creazione di un nuovo task, di una nuova nota o di un evento a calendario (ad es. "crea un task per domani su RFXANK" oppure "aggiungi nota per esperimento PC1"), includi alla fine della risposta un blocco JSON strutturato delimitato da \`\`\`json_action e \`\`\` contenente l'azione suggerita.
Formato azione per task:
\`\`\`json_action
{
  "type": "CREATE_TASK",
  "data": {
    "title": "...",
    "description": "...",
    "priority": "alta" | "media" | "bassa",
    "project": "RFXANK / MHC-II" | "VUS leucemia" | "HSC biology" | "Personale" | "Altro",
    "dueDate": "YYYY-MM-DD"
  }
}
\`\`\`

Formato azione per nota:
\`\`\`json_action
{
  "type": "CREATE_NOTE",
  "data": {
    "title": "...",
    "content": "...",
    "project": "RFXANK / MHC-II" | "VUS leucemia" | "HSC biology" | "Personale" | "Altro"
  }
}
\`\`\`

Formato azione per evento calendario:
\`\`\`json_action
{
  "type": "CREATE_EVENT",
  "data": {
    "title": "...",
    "startTime": "YYYY-MM-DDTHH:mm",
    "endTime": "YYYY-MM-DDTHH:mm",
    "location": "...",
    "calendarName": "Lab" | "Personale"
  }
}
\`\`\`
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const reply = response.text || "Non sono riuscito a elaborare la tua richiesta.";

    // Parse potential json_action from reply
    let action = null;
    const actionMatch = reply.match(/```json_action\s*([\s\S]*?)\s*```/);
    if (actionMatch && actionMatch[1]) {
      try {
        action = JSON.parse(actionMatch[1]);
      } catch (e) {
        console.error("Failed to parse action JSON:", e);
      }
    }

    // Clean reply text of json_action block for clean markdown rendering
    const cleanReply = reply.replace(/```json_action\s*[\s\S]*?\s*```/g, "").trim();

    res.json({ reply: cleanReply, action });
  } catch (err: any) {
    console.error("Error in /api/agent:", err);
    res.status(500).json({
      error: err.message || "Si è verificato un errore nell'elaborazione con l'Agente AI.",
    });
  }
});

// API: DOI / PubMed metadata lookup
app.get("/api/pubmed", async (req, res) => {
  const { query } = req.query;
  if (!query || typeof query !== "string") {
    return res.status(400).json({ error: "Query parameter (DOI or PubMed ID) is required" });
  }

  const cleanQuery = query.trim();

  try {
    // 1. Try CrossRef API if query looks like a DOI (starts with 10.)
    if (cleanQuery.startsWith("10.") || cleanQuery.includes("10.")) {
      const doi = cleanQuery.replace(/^https?:\/\/doi\.org\//, "");
      const crossRefRes = await fetch(`https://api.crossref.org/works/${encodeURIComponent(doi)}`);
      if (crossRefRes.ok) {
        const data = await crossRefRes.json();
        const item = data.message;
        const authors = (item.author || []).map((a: any) => `${a.given || ''} ${a.family || ''}`.trim()).join(", ");
        const journal = Array.isArray(item["container-title"]) ? item["container-title"][0] : item["container-title"] || "";
        const year = item.created?.["date-parts"]?.[0]?.[0] || item.issued?.["date-parts"]?.[0]?.[0] || new Date().getFullYear();
        const title = Array.isArray(item.title) ? item.title[0] : item.title || "Untitled Paper";
        const abstract = (item.abstract || "").replace(/<[^>]*>?/gm, "");

        return res.json({
          title,
          authors: authors || "Unknown Authors",
          journal: journal || "Academic Journal",
          year: Number(year),
          doi: doi,
          url: `https://doi.org/${doi}`,
          abstract: abstract || "Abstract non disponibile direttamente via CrossRef. Inserire una nota sintetica.",
        });
      }
    }

    // 2. Fallback to NCBI EuropePMC / PubMed API
    const epmcRes = await fetch(
      `https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=${encodeURIComponent(
        cleanQuery
      )}&format=json`
    );
    if (epmcRes.ok) {
      const data = await epmcRes.json();
      const firstResult = data.resultList?.result?.[0];
      if (firstResult) {
        return res.json({
          title: firstResult.title || "Untitled Paper",
          authors: firstResult.authorString || "Unknown Authors",
          journal: firstResult.journalTitle || "Medical Journal",
          year: Number(firstResult.pubYear || new Date().getFullYear()),
          doi: firstResult.doi || cleanQuery,
          url: firstResult.doi ? `https://doi.org/${firstResult.doi}` : `https://pubmed.ncbi.nlm.nih.gov/${firstResult.pmid || ''}`,
          abstract: firstResult.abstractText || "Abstract recuperato da EuropePMC.",
        });
      }
    }

    // Default response fallback if external APIs returned no match
    return res.json({
      title: `Articolo scientifico: ${cleanQuery}`,
      authors: "Ricercatori Gene & Cell Therapy",
      journal: "Nature Biotechnology / Molecular Therapy",
      year: new Date().getFullYear(),
      doi: cleanQuery,
      url: cleanQuery.startsWith("http") ? cleanQuery : `https://doi.org/${cleanQuery}`,
      abstract: "Metadati generati automaticamente per la ricerca di Davide.",
    });
  } catch (err: any) {
    console.error("Error fetching pubmed data:", err);
    res.status(500).json({ error: "Errore nel recupero dei metadati dell'articolo scientifico." });
  }
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ResearchHub server active on http://localhost:${PORT}`);
  });
}

startServer();
