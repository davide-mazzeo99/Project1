import {
  TaskItem,
  NoteItem,
  PaperItem,
  CalendarEventItem,
  NewsPublicationItem,
  ProjectCategory,
} from "../types";

export const INITIAL_PROJECTS: ProjectCategory[] = [
  {
    id: "proj-1",
    name: "RFXANK / MHC-II",
    description: "Terapia genica per immunodeficienza da deficit di RFXANK e ripristino dell'espressione di MHC di classe II.",
    color: "violet",
    accentHex: "#8B5CF6",
  },
  {
    id: "proj-2",
    name: "VUS leucemia",
    description: "Caratterizzazione funzionale di varianti di significato incerto (VUS) in geni tumorali ematologici.",
    color: "blue",
    accentHex: "#3B82F6",
  },
  {
    id: "proj-3",
    name: "HSC biology",
    description: "Ottimizzazione di vettori lentivirali e ribonucleoproteine CRISPR/Cas9 in cellule staminali ematopoietiche.",
    color: "emerald",
    accentHex: "#10B981",
  },
  {
    id: "proj-4",
    name: "Personale",
    description: "Scadenze dottorato, presentazione report annuale PhD, corso di bioinformatica.",
    color: "amber",
    accentHex: "#F59E0B",
  },
  {
    id: "proj-5",
    name: "Altro",
    description: "Attività trasversali, manutenzione strumentazione di laboratorio e reagenti.",
    color: "slate",
    accentHex: "#64748B",
  },
];

// Helper to format dates relative to today
const today = new Date();
const formatDate = (offsetDays: number = 0) => {
  const d = new Date(today);
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().split("T")[0];
};

const formatIsoTime = (offsetDays: number, hour: number, minute: number = 0) => {
  const d = new Date(today);
  d.setDate(d.getDate() + offsetDays);
  d.setHours(hour, minute, 0, 0);
  return d.toISOString().slice(0, 16);
};

export const INITIAL_TASKS: TaskItem[] = [
  {
    id: "task-1",
    title: "Analisi FACS espressione MHC-II su CD34+ post-editing RFXANK",
    description: "Verificare la percentuale di ripristino della proteina HLA-DR mediante citofluorimetria dopo elettroporazione di RNP Cas9 e ssODN.",
    dueDate: formatDate(0), // Today
    priority: "alta",
    status: "in corso",
    project: "RFXANK / MHC-II",
    createdAt: formatDate(-2),
    linkedPaperId: "paper-1",
  },
  {
    id: "task-2",
    title: "Preparare plasmidi per saggio di luciferasi su VUS CDH7 e RUNX1",
    description: "Eseguire miniprep di 8 cloni VUS per transfezione in cellule HEK293T e misurazione dell'attività trascrizionale.",
    dueDate: formatDate(1), // Tomorrow
    priority: "alta",
    status: "da fare",
    project: "VUS leucemia",
    createdAt: formatDate(-1),
  },
  {
    id: "task-3",
    title: "Testare cocktail di citochine per espansione ex-vivo di HSC",
    description: "Confrontare UM171 vs SR1 per mantenere la staminalità (CD34+ CD38- CD90+) prima della trasduzione lentivirale.",
    dueDate: formatDate(3),
    priority: "media",
    status: "da fare",
    project: "HSC biology",
    createdAt: formatDate(-3),
    linkedNoteId: "note-1",
  },
  {
    id: "task-4",
    title: "Revisione report annuale PhD e diapositive per la commissione",
    description: "Completare la bozza della presentazione da 20 minuti con i dati preliminari sul correttivo genetico di RFXANK.",
    dueDate: formatDate(5),
    priority: "alta",
    status: "in corso",
    project: "Personale",
    createdAt: formatDate(-5),
  },
  {
    id: "task-5",
    title: "Ordinare kit dPCR e reagenti di trasfezione per laboratorio",
    description: "Richiedere preventivo per probe TaqMan specifiche per la giunzione exon 3-4 di RFXANK e kit Neon electroporation.",
    dueDate: formatDate(-1), // Overdue
    priority: "bassa",
    status: "da fare",
    project: "Altro",
    createdAt: formatDate(-4),
  },
  {
    id: "task-6",
    title: "Sequenziamento ampliconi Next-Gen Sequencing (NGS)",
    description: "Inviare le librerie di amplicone per quantificare l'efficienza di in/del e target editing nei loci di interesse.",
    dueDate: formatDate(-3),
    priority: "media",
    status: "fatto",
    project: "RFXANK / MHC-II",
    createdAt: formatDate(-7),
  },
];

export const INITIAL_NOTES: NoteItem[] = [
  {
    id: "note-1",
    title: "Protocollo Elettroporazione RNP + ssODN in HSC CD34+",
    content: `# Protocollo Ottimizzato per HSC Editing (RFXANK)

## Condizioni Elettroporatore Neon:
- **Tensione**: 1600 V
- **Ampiezza impulso**: 10 ms
- **Numero impulsi**: 3
- **Rapporto Cas9:sgRNA**: 1:2.5 molar ratio

## Note Sperimentali:
- Pre-incubare il complesso RNP per 15 min a temperatura ambiente.
- La vitalità cellulare a 24h post-elettroporazione è risultata dell'84% con aggiunta di inibitore p53 transitorio (M3814).
- L'espressione di MHC-II (HLA-DR) comincia ad essere rilevabile al FACS a 72 ore post-editing.

## Azioni da intraprendere:
- Valutare l'impatto di pegylated ssODN per ridurre la citotossicità.`,
    project: "RFXANK / MHC-II",
    createdAt: formatDate(-4),
    updatedAt: formatDate(-1),
    linkedTaskId: "task-1",
    linkedPaperId: "paper-1",
  },
  {
    id: "note-2",
    title: "Appunti riunione con Prof. Rossi su VUS Leucemia",
    content: `# Meeting 26 Luglio - Strategia VUS

- I dati sul saggio reporter confermano che la variante c.412C>T causa uno splicing aberrante nel gene di controllo.
- **Prossimo passo**: Generare linee cellulari isogeniche K562 tramite Prime Editing pegRNA per confermare il fenotipo patogenetico.
- Preparare la figura 3 per la sottomissione dell'articolo su *Blood Advances*.`,
    project: "VUS leucemia",
    createdAt: formatDate(-6),
    updatedAt: formatDate(-2),
    linkedTaskId: "task-2",
  },
  {
    id: "note-3",
    title: "Idee per tesi di dottorato & Horizon Europe Grant",
    content: `# Strategia Tesi PhD Davide

1. **Capitolo 1**: Introduzione alla Gene & Cell Therapy per deficit di MHC di classe II.
2. **Capitolo 2**: Confronto tra Lentivirus, Base Editing e Prime Editing nel locus RFXANK.
3. **Capitolo 3**: Sicurezza off-target (GUIDE-seq e CIRCLE-seq).
4. **Capitolo 4**: Ripristino immunologico in modelli organoidi e primari.`,
    project: "Personale",
    createdAt: formatDate(-10),
    updatedAt: formatDate(-3),
  },
];

export const INITIAL_PAPERS: PaperItem[] = [
  {
    id: "paper-1",
    title: "Correction of RFXANK deficiency in hematopoietic stem cells restores MHC class II expression and immune competence",
    authors: "Davide M., Rossi G., Smith A., et al.",
    journal: "Nature Biotechnology",
    year: 2024,
    doi: "10.1038/s41587-023-01980-6",
    url: "https://doi.org/10.1038/s41587-023-01980-6",
    abstract: "Bare lymphocyte syndrome type II is caused by mutations in RFXANK impairing MHC-II expression. Here we present a highly efficient CRISPR-Cas9 genome editing strategy in CD34+ hematopoietic stem cells that achieves >75% gene correction with sustained reconstitution in humanized mice.",
    project: "RFXANK / MHC-II",
    status: "importante",
    personalNotes: "Articolo chiave per il mio progetto di dottorato. Metodologia di elettroporazione da replicare in lab.",
    citationsCount: 142,
    addedAt: formatDate(-12),
  },
  {
    id: "paper-2",
    title: "Functional classification of genomic variants of uncertain significance in pediatric acute lymphoblastic leukemia",
    authors: "Chen L., Zhang W., Miller K., et al.",
    journal: "Blood",
    year: 2024,
    doi: "10.1182/blood.2023021456",
    url: "https://doi.org/10.1182/blood.2023021456",
    abstract: "High-throughput saturation genome editing allows systematic functional mapping of VUS in leukemia predisposition genes, identifying pathogenic misfolding variants amenable to small-molecule chaperones.",
    project: "VUS leucemia",
    status: "letto",
    personalNotes: "Ottimo pannello di saggi reporter per valutare le varianti in RUNX1 e CDH7.",
    citationsCount: 89,
    addedAt: formatDate(-8),
  },
  {
    id: "paper-3",
    title: "Prime editing enables precise genome modification in human hematopoietic stem and progenitor cells without double-strand breaks",
    authors: "Anzalone A.V., Gao X.D., Podracky C.J., et al.",
    journal: "Nature Biomedical Engineering",
    year: 2023,
    doi: "10.1038/s41551-023-01045-8",
    url: "https://doi.org/10.1038/s41551-023-01045-8",
    abstract: "Engineered pegRNAs and modified reverse transcriptases facilitate efficient base and prime insertions in human CD34+ HSCs while maintaining repopulating capacity and low insertion-deletion ratios.",
    project: "HSC biology",
    status: "da leggere",
    personalNotes: "Leggere la sezione sui metodi di consegna lipidica (LNP) vs elettroporazione.",
    citationsCount: 215,
    addedAt: formatDate(-5),
  },
  {
    id: "paper-4",
    title: "Long-term safety and efficacy of ex vivo gene therapy for severe inherited immunodeficiencies",
    authors: "Aiuti A., Roncarolo M.G., Naldini L.",
    journal: "The Lancet Haematology",
    year: 2023,
    doi: "10.1016/S2352-3026(23)00112-9",
    url: "https://doi.org/10.1016/S2352-3026(23)00112-9",
    abstract: "A comprehensive decade-long follow-up of clinical trials evaluating autologous stem cell gene therapy confirms absence of insertional mutagenesis and sustained polyclonal reconstitution.",
    project: "RFXANK / MHC-II",
    status: "letto",
    personalNotes: "Citazione fondamentale per l'introduzione della tesi.",
    citationsCount: 310,
    addedAt: formatDate(-15),
  },
];

export const INITIAL_CALENDAR_EVENTS: CalendarEventItem[] = [
  {
    id: "evt-1",
    title: "Citofluorimetria FACS (RFXANK HLA-DR)",
    startTime: formatIsoTime(0, 9, 30),
    endTime: formatIsoTime(0, 11, 30),
    location: "Stanza 204 - Facility Citometria",
    description: "Analisi delle cellule CD34+ modificate a 72h dall'elettroporazione.",
    calendarName: "Esperimenti",
    project: "RFXANK / MHC-II",
  },
  {
    id: "evt-2",
    title: "Lab Meeting Settimanale - Gruppo Gene Therapy",
    startTime: formatIsoTime(0, 14, 0),
    endTime: formatIsoTime(0, 15, 30),
    location: "Sala Riunioni Piano 3 / Zoom",
    description: "Presentazione dello stato di avanzamento sui cloni VUS e discussione acquisti reagenti.",
    calendarName: "Lab",
    project: "Altro",
  },
  {
    id: "evt-3",
    title: "Incontro con Relatore PhD (Prof. Rossi)",
    startTime: formatIsoTime(1, 11, 0),
    endTime: formatIsoTime(1, 12, 0),
    location: "Ufficio Direzione Ricerca",
    description: "Revisione della bozza del report di dottorato e programmazione esperimenti in vivo.",
    calendarName: "Personale",
    project: "Personale",
  },
  {
    id: "evt-4",
    title: "Seminario: Novel LNP Delivery Systems for RNA Editing",
    startTime: formatIsoTime(2, 16, 0),
    endTime: formatIsoTime(2, 17, 30),
    location: "Aula Magna Ospedale San Raffaele",
    description: "Speaker ospite Dr. Sarah Jenkins (Harvard Medical School).",
    calendarName: "Seminari",
    project: "HSC biology",
  },
  {
    id: "evt-5",
    title: "Transfezione Cellule HEK293T per saggio VUS",
    startTime: formatIsoTime(3, 10, 0),
    endTime: formatIsoTime(3, 13, 0),
    location: "Cappa Flusso Laminare 2",
    description: "Transfezione plasmidica con Lipofectamine 3000.",
    calendarName: "Esperimenti",
    project: "VUS leucemia",
  },
];

export const INITIAL_NEWS_ITEMS: NewsPublicationItem[] = [
  {
    id: "news-1",
    title: "FDA approva prima terapia in vivo con CRISPR per patologie rare del sangue",
    source: "Biotech Gene & Cell News",
    date: formatDate(-1),
    link: "https://www.fda.gov/news-events",
    summary: "L'agenzia statunitense ha autorizzato la sperimentazione clinica di fase 1/2 per una somministrazione sistemica basata su LNP per l'editing di precisione nelle cellule staminali del midollo.",
    category: "news",
    tags: ["FDA", "CRISPR", "Gene Therapy", "LNP"],
  },
  {
    id: "news-2",
    title: "Nuove strategie di sintesi di pegRNA migliorano l'efficienza di Prime Editing di 4 volte",
    source: "Molecular Therapy Journal",
    date: formatDate(-2),
    link: "https://www.cell.com/molecular-therapy",
    summary: "Un consorzio di ricerca europeo dimostra che la modificazione chimica delle estremità 3' dei pegRNA protegge la molecola dalle esonucleasi cellulari nelle HSC umane.",
    category: "pubblicazione",
    tags: ["Prime Editing", "pegRNA", "HSC", "RNA Stability"],
    doi: "10.1016/j.ymthe.2024.04.012",
    journal: "Molecular Therapy",
  },
  {
    id: "news-3",
    title: "Simposio Europeo di Terapia Genica e Cellulare (ESGCT) 2026: Aperte le iscrizioni",
    source: "ESGCT Official",
    date: formatDate(-4),
    link: "https://www.esgct.eu",
    summary: "Inviati oltre 1,500 abstract dedicati all'editing genomico non virale, allo sviluppo di CAR-T allogeniche e alla correzione ex-vivo delle immunodeficit primarie.",
    category: "news",
    tags: ["ESGCT", "Conferenza", "Immunodeficienze"],
  },
  {
    id: "news-4",
    title: "Unraveling RFXANK Promoter Architecture Reveals Novel Enhancer Modules for MHC-II Expression",
    source: "Nature Cell Biology",
    date: formatDate(-5),
    link: "https://doi.org/10.1038/s41556-024-01388-1",
    summary: "Studio strutturale che identifica gli elementi regolatori prossimali del complesso RFX nell'assemblaggio del transattivatore CIITA per il ripristino dell'immunità adattativa.",
    category: "pubblicazione",
    tags: ["RFXANK", "MHC-II", "CIITA", "Epigenetica"],
    doi: "10.1038/s41556-024-01388-1",
    journal: "Nature Cell Biology",
  },
  {
    id: "news-5",
    title: "Base Editing vs Prime Editing in Hematopoietic Stem Cells: A Head-to-Head Off-Target Safety Benchmark",
    source: "Blood Advances",
    date: formatDate(-7),
    link: "https://ashpublications.org/bloodadvances",
    summary: "Confronto diretto sulle traslocazioni cromosomiche indesiderate e sulle risposte al danno al DNA (p53 activation) in progenitori ematopoietici primari.",
    category: "pubblicazione",
    tags: ["Base Editing", "Prime Editing", "HSC", "Safety"],
    doi: "10.1182/bloodadvances.2024011920",
    journal: "Blood Advances",
  },
];
