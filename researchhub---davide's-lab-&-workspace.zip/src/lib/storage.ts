import {
  TaskItem,
  NoteItem,
  PaperItem,
  CalendarEventItem,
  NewsPublicationItem,
  ProjectCategory,
} from "../types";
import {
  INITIAL_TASKS,
  INITIAL_NOTES,
  INITIAL_PAPERS,
  INITIAL_CALENDAR_EVENTS,
  INITIAL_NEWS_ITEMS,
  INITIAL_PROJECTS,
} from "../data/initialData";

const STORAGE_KEYS = {
  TASKS: "researchhub_tasks_v1",
  NOTES: "researchhub_notes_v1",
  PAPERS: "researchhub_papers_v1",
  EVENTS: "researchhub_events_v1",
  NEWS: "researchhub_news_v1",
  PROJECTS: "researchhub_projects_v1",
  HEADLINE_INDEX: "researchhub_headline_idx_v1",
};

type Listener = () => void;
const listeners = new Set<Listener>();

export const subscribeStorage = (listener: Listener) => {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
};

const notifyListeners = () => {
  listeners.forEach((l) => l());
};

// Safe JSON parse with fallback
function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.warn(`Failed to parse ${key} from storage:`, e);
  }
  return fallback;
}

function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Failed to save ${key} to storage:`, e);
  }
  notifyListeners();
}

// Tasks
export const getTasks = (): TaskItem[] => loadFromStorage(STORAGE_KEYS.TASKS, INITIAL_TASKS);
export const saveTask = (task: TaskItem): void => {
  const tasks = getTasks();
  const existingIdx = tasks.findIndex((t) => t.id === task.id);
  if (existingIdx >= 0) {
    tasks[existingIdx] = task;
  } else {
    tasks.unshift(task);
  }
  saveToStorage(STORAGE_KEYS.TASKS, tasks);
};
export const deleteTask = (id: string): void => {
  const tasks = getTasks().filter((t) => t.id !== id);
  saveToStorage(STORAGE_KEYS.TASKS, tasks);
};

// Notes
export const getNotes = (): NoteItem[] => loadFromStorage(STORAGE_KEYS.NOTES, INITIAL_NOTES);
export const saveNote = (note: NoteItem): void => {
  const notes = getNotes();
  const existingIdx = notes.findIndex((n) => n.id === note.id);
  if (existingIdx >= 0) {
    notes[existingIdx] = note;
  } else {
    notes.unshift(note);
  }
  saveToStorage(STORAGE_KEYS.NOTES, notes);
};
export const deleteNote = (id: string): void => {
  const notes = getNotes().filter((n) => n.id !== id);
  saveToStorage(STORAGE_KEYS.NOTES, notes);
};

// Papers
export const getPapers = (): PaperItem[] => loadFromStorage(STORAGE_KEYS.PAPERS, INITIAL_PAPERS);
export const savePaper = (paper: PaperItem): void => {
  const papers = getPapers();
  const existingIdx = papers.findIndex((p) => p.id === paper.id);
  if (existingIdx >= 0) {
    papers[existingIdx] = paper;
  } else {
    papers.unshift(paper);
  }
  saveToStorage(STORAGE_KEYS.PAPERS, papers);
};
export const deletePaper = (id: string): void => {
  const papers = getPapers().filter((p) => p.id !== id);
  saveToStorage(STORAGE_KEYS.PAPERS, papers);
};

// Calendar Events
export const getCalendarEvents = (): CalendarEventItem[] =>
  loadFromStorage(STORAGE_KEYS.EVENTS, INITIAL_CALENDAR_EVENTS);
export const saveCalendarEvent = (event: CalendarEventItem): void => {
  const events = getCalendarEvents();
  const existingIdx = events.findIndex((e) => e.id === event.id);
  if (existingIdx >= 0) {
    events[existingIdx] = event;
  } else {
    events.unshift(event);
  }
  saveToStorage(STORAGE_KEYS.EVENTS, events);
};
export const deleteCalendarEvent = (id: string): void => {
  const events = getCalendarEvents().filter((e) => e.id !== id);
  saveToStorage(STORAGE_KEYS.EVENTS, events);
};

// News items
export const getNewsItems = (): NewsPublicationItem[] =>
  loadFromStorage(STORAGE_KEYS.NEWS, INITIAL_NEWS_ITEMS);

// Projects
export const getProjects = (): ProjectCategory[] =>
  loadFromStorage(STORAGE_KEYS.PROJECTS, INITIAL_PROJECTS);

// Selected Hero Headline Index
export const getSelectedHeadlineIndex = (): number =>
  loadFromStorage(STORAGE_KEYS.HEADLINE_INDEX, 0);
export const setSelectedHeadlineIndex = (idx: number): void =>
  saveToStorage(STORAGE_KEYS.HEADLINE_INDEX, idx);
