export type ProjectName =
  | "RFXANK / MHC-II"
  | "VUS leucemia"
  | "HSC biology"
  | "Personale"
  | "Altro";

export type Priority = "bassa" | "media" | "alta";
export type TaskStatus = "da fare" | "in corso" | "fatto";
export type PaperStatus = "da leggere" | "letto" | "importante";
export type CalendarName = "Lab" | "Personale" | "Seminari" | "Esperimenti";

export interface TaskItem {
  id: string;
  title: string;
  description: string;
  dueDate: string; // YYYY-MM-DD
  priority: Priority;
  status: TaskStatus;
  project: ProjectName;
  linkedNoteId?: string;
  linkedPaperId?: string;
  createdAt: string;
}

export interface NoteItem {
  id: string;
  title: string;
  content: string; // Markdown or rich text
  project: ProjectName;
  createdAt: string;
  updatedAt: string;
  linkedTaskId?: string;
  linkedPaperId?: string;
}

export interface PaperItem {
  id: string;
  title: string;
  authors: string;
  journal: string;
  year: number;
  doi?: string;
  url?: string;
  abstract: string;
  project: ProjectName;
  status: PaperStatus;
  personalNotes: string;
  citationsCount?: number;
  addedAt: string;
}

export interface CalendarEventItem {
  id: string;
  externalGoogleId?: string;
  title: string;
  startTime: string; // ISO string e.g. 2026-07-30T10:00
  endTime: string;   // ISO string e.g. 2026-07-30T11:30
  location?: string;
  description?: string;
  calendarName: CalendarName;
  project?: ProjectName;
}

export interface NewsPublicationItem {
  id: string;
  title: string;
  source: string;
  date: string;
  link: string;
  summary: string;
  category: "news" | "pubblicazione";
  tags: string[];
  doi?: string;
  journal?: string;
}

export interface ProjectCategory {
  id: string;
  name: ProjectName;
  description: string;
  color: string;
  accentHex: string;
}

export interface AgentAction {
  type: "CREATE_TASK" | "CREATE_NOTE" | "CREATE_EVENT";
  data: any;
}

export interface AgentMessage {
  id: string;
  sender: "user" | "assistant";
  text: string;
  timestamp: string;
  action?: AgentAction;
  actionExecuted?: boolean;
}
