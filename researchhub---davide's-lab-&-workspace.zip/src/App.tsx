import React, { useState, useEffect } from "react";
import { Sidebar } from "./components/Sidebar";
import { Header } from "./components/Header";
import { HomeView } from "./components/views/HomeView";
import { CalendarView } from "./components/views/CalendarView";
import { TasksView } from "./components/views/TasksView";
import { NotesView } from "./components/views/NotesView";
import { PapersView } from "./components/views/PapersView";
import { NewsView } from "./components/views/NewsView";
import { AiAssistantDrawer } from "./components/AiAssistantDrawer";

import {
  TaskItem,
  NoteItem,
  PaperItem,
  CalendarEventItem,
  NewsPublicationItem,
  ProjectCategory,
} from "./types";

import {
  subscribeStorage,
  getTasks,
  saveTask,
  deleteTask,
  getNotes,
  saveNote,
  deleteNote,
  getPapers,
  savePaper,
  deletePaper,
  getCalendarEvents,
  saveCalendarEvent,
  deleteCalendarEvent,
  getNewsItems,
  getProjects,
} from "./lib/storage";

export default function App() {
  const [currentView, setCurrentView] = useState<string>("home");
  const [activeProjectFilter, setActiveProjectFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState(false);

  // State
  const [tasks, setTasks] = useState<TaskItem[]>(getTasks);
  const [notes, setNotes] = useState<NoteItem[]>(getNotes);
  const [papers, setPapers] = useState<PaperItem[]>(getPapers);
  const [events, setEvents] = useState<CalendarEventItem[]>(getCalendarEvents);
  const [newsItems, setNewsItems] = useState<NewsPublicationItem[]>(getNewsItems);
  const [projects, setProjects] = useState<ProjectCategory[]>(getProjects);

  const refreshState = () => {
    setTasks(getTasks());
    setNotes(getNotes());
    setPapers(getPapers());
    setEvents(getCalendarEvents());
    setNewsItems(getNewsItems());
    setProjects(getProjects());
  };

  useEffect(() => {
    const unsubscribe = subscribeStorage(() => {
      refreshState();
    });
    return unsubscribe;
  }, []);

  const handleSaveTask = (task: TaskItem) => {
    saveTask(task);
    refreshState();
  };

  const handleDeleteTask = (id: string) => {
    deleteTask(id);
    refreshState();
  };

  const handleSaveNote = (note: NoteItem) => {
    saveNote(note);
    refreshState();
  };

  const handleDeleteNote = (id: string) => {
    deleteNote(id);
    refreshState();
  };

  const handleSavePaper = (paper: PaperItem) => {
    savePaper(paper);
    refreshState();
  };

  const handleDeletePaper = (id: string) => {
    deletePaper(id);
    refreshState();
  };

  const handleSaveEvent = (event: CalendarEventItem) => {
    saveCalendarEvent(event);
    refreshState();
  };

  const handleDeleteEvent = (id: string) => {
    deleteCalendarEvent(id);
    refreshState();
  };

  return (
    <div className="flex h-screen bg-[#0B0E14] font-sans text-slate-100 overflow-hidden antialiased">
      {/* Sidebar Navigation matching reference UI */}
      <Sidebar
        currentView={currentView}
        onSelectView={setCurrentView}
        projects={projects}
        activeProjectFilter={activeProjectFilter}
        onSelectProjectFilter={setActiveProjectFilter}
        tasksCount={tasks.filter((t) => t.status !== "fatto").length}
        papersCount={papers.length}
        onOpenAiDrawer={() => setIsAiDrawerOpen(true)}
      />

      {/* Main Container */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Top Header */}
        <Header
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onOpenAiDrawer={() => setIsAiDrawerOpen(true)}
          onSelectView={setCurrentView}
        />

        {/* View Content Body */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            {currentView === "home" && (
              <HomeView
                tasks={tasks}
                notes={notes}
                papers={papers}
                events={events}
                projects={projects}
                onSelectView={setCurrentView}
                onRefreshData={refreshState}
              />
            )}

            {currentView === "calendar" && (
              <CalendarView
                events={events}
                onSaveEvent={handleSaveEvent}
                onDeleteEvent={handleDeleteEvent}
              />
            )}

            {currentView === "tasks" && (
              <TasksView
                tasks={tasks}
                notes={notes}
                papers={papers}
                onSaveTask={handleSaveTask}
                onDeleteTask={handleDeleteTask}
                activeProjectFilter={activeProjectFilter}
                onSelectProjectFilter={setActiveProjectFilter}
              />
            )}

            {currentView === "notes" && (
              <NotesView
                notes={notes}
                tasks={tasks}
                papers={papers}
                onSaveNote={handleSaveNote}
                onDeleteNote={handleDeleteNote}
                activeProjectFilter={activeProjectFilter}
                onSelectProjectFilter={setActiveProjectFilter}
              />
            )}

            {currentView === "papers" && (
              <PapersView
                papers={papers}
                onSavePaper={handleSavePaper}
                onDeletePaper={handleDeletePaper}
                activeProjectFilter={activeProjectFilter}
                onSelectProjectFilter={setActiveProjectFilter}
              />
            )}

            {currentView === "news" && (
              <NewsView
                newsItems={newsItems}
                onSavePaper={handleSavePaper}
                savedPaperDois={papers.map((p) => p.doi || "").filter(Boolean)}
              />
            )}
          </div>
        </main>
      </div>

      {/* Slide-over AI Assistant Drawer */}
      <AiAssistantDrawer
        isOpen={isAiDrawerOpen}
        onClose={() => setIsAiDrawerOpen(false)}
        onRefreshData={refreshState}
      />
    </div>
  );
}
