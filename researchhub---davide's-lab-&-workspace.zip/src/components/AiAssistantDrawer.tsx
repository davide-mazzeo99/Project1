import React, { useState } from "react";
import {
  Sparkles,
  X,
  Send,
  Loader2,
  CheckCircle2,
  PlusCircle,
  Bot,
  User,
  FlaskConical,
} from "lucide-react";
import { AgentMessage, AgentAction } from "../types";
import {
  saveTask,
  saveNote,
  saveCalendarEvent,
  getTasks,
  getNotes,
  getPapers,
  getCalendarEvents,
} from "../lib/storage";

interface AiAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onRefreshData?: () => void;
}

export const AiAssistantDrawer: React.FC<AiAssistantDrawerProps> = ({
  isOpen,
  onClose,
  onRefreshData,
}) => {
  const [prompt, setPrompt] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<AgentMessage[]>([
    {
      id: "welcome",
      sender: "assistant",
      text: "Ciao Davide! Sono il tuo Agente AI di laboratorio. Come posso aiutarti oggi con agenda, task, note o paper?",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [executedActions, setExecutedActions] = useState<Record<string, boolean>>({});

  if (!isOpen) return null;

  const handleSendPrompt = async (textToSend?: string) => {
    const finalPrompt = (textToSend || prompt).trim();
    if (!finalPrompt || isLoading) return;

    const userMsgId = `user-${Date.now()}`;
    setMessages((prev) => [
      ...prev,
      {
        id: userMsgId,
        sender: "user",
        text: finalPrompt,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      },
    ]);

    setPrompt("");
    setIsLoading(true);

    try {
      const context = {
        tasks: getTasks(),
        notes: getNotes(),
        papers: getPapers(),
        events: getCalendarEvents(),
        currentDate: new Date().toISOString().split("T")[0],
      };

      const res = await fetch("/api/agent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: finalPrompt, context }),
      });

      if (!res.ok) throw new Error("Errore durante l'interazione con l'Agente AI");
      const data = await res.json();

      setMessages((prev) => [
        ...prev,
        {
          id: `asst-${Date.now()}`,
          sender: "assistant",
          text: data.reply || "Ho controllato i dati del tuo laboratorio.",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          action: data.action,
        },
      ]);
    } catch (err: any) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: `asst-err-${Date.now()}`,
          sender: "assistant",
          text: `Si è verificato un errore: ${err.message}`,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleExecuteAction = (msgId: string, action: AgentAction) => {
    try {
      if (action.type === "CREATE_TASK") {
        saveTask({
          id: `task-ai-${Date.now()}`,
          title: action.data.title || "Nuovo task AI",
          description: action.data.description || "",
          dueDate: action.data.dueDate || new Date().toISOString().split("T")[0],
          priority: action.data.priority || "media",
          status: "da fare",
          project: action.data.project || "RFXANK / MHC-II",
          createdAt: new Date().toISOString().split("T")[0],
        });
      } else if (action.type === "CREATE_NOTE") {
        saveNote({
          id: `note-ai-${Date.now()}`,
          title: action.data.title || "Nuova Nota AI",
          content: action.data.content || "",
          project: action.data.project || "RFXANK / MHC-II",
          createdAt: new Date().toISOString().split("T")[0],
          updatedAt: new Date().toISOString().split("T")[0],
        });
      } else if (action.type === "CREATE_EVENT") {
        saveCalendarEvent({
          id: `evt-ai-${Date.now()}`,
          title: action.data.title || "Evento AI",
          startTime: action.data.startTime || new Date().toISOString().slice(0, 16),
          endTime: action.data.endTime || new Date().toISOString().slice(0, 16),
          location: action.data.location || "Lab",
          calendarName: action.data.calendarName || "Lab",
          project: "RFXANK / MHC-II",
        });
      }

      setExecutedActions((prev) => ({ ...prev, [msgId]: true }));
      if (onRefreshData) onRefreshData();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex justify-end">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between border-l border-slate-200">
        {/* Drawer Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-gradient-to-r from-indigo-600 to-violet-600 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-sm">Agente AI Lab Assistant</h3>
              <p className="text-[10px] text-white/80">
                PhD Gene & Cell Therapy Helper
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages Body */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/50">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${
                msg.sender === "user" ? "flex-row-reverse" : "flex-row"
              }`}
            >
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                  msg.sender === "user"
                    ? "bg-indigo-600 text-white"
                    : "bg-violet-600 text-white"
                }`}
              >
                {msg.sender === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div className="space-y-1.5 max-w-[80%]">
                <div
                  className={`p-3 rounded-2xl text-xs ${
                    msg.sender === "user"
                      ? "bg-indigo-600 text-white rounded-tr-none shadow-2xs"
                      : "bg-white text-slate-800 rounded-tl-none border border-slate-200/80 shadow-2xs"
                  }`}
                >
                  <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                </div>

                {msg.action && (
                  <div className="p-2.5 bg-white rounded-xl border border-indigo-200 shadow-2xs space-y-2 text-xs">
                    <p className="font-bold text-slate-900">
                      Azione proposta: {msg.action.type.replace("_", " ")}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      {msg.action.data.title || "Dettagli dell'azione"}
                    </p>

                    {executedActions[msg.id] ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Eseguito con successo!
                      </span>
                    ) : (
                      <button
                        onClick={() => handleExecuteAction(msg.id, msg.action!)}
                        className="w-full py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-[11px] shadow-2xs cursor-pointer"
                      >
                        Conferma ed Esegui
                      </button>
                    )}
                  </div>
                )}

                <p className="text-[9px] text-slate-400 px-1">
                  {msg.timestamp}
                </p>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-xs text-indigo-600 font-medium">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Sto controllando i tuoi dati...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-white border-t border-slate-200 space-y-2">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendPrompt();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Chiedimi qualcosa..."
              disabled={isLoading}
              className="flex-1 px-3 py-2 bg-slate-100 rounded-xl text-xs text-slate-900 border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
            <button
              type="submit"
              disabled={isLoading || !prompt.trim()}
              className="p-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
