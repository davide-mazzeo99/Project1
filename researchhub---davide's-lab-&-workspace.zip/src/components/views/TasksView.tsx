import React, { useState } from "react";
import {
  CheckSquare,
  Plus,
  Filter,
  Calendar,
  Tag,
  Clock,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertCircle,
  FileText,
  BookOpen,
  Link2,
} from "lucide-react";
import {
  TaskItem,
  ProjectName,
  Priority,
  TaskStatus,
  NoteItem,
  PaperItem,
} from "../../types";

interface TasksViewProps {
  tasks: TaskItem[];
  notes: NoteItem[];
  papers: PaperItem[];
  onSaveTask: (task: TaskItem) => void;
  onDeleteTask: (id: string) => void;
  activeProjectFilter: string | null;
  onSelectProjectFilter: (proj: string | null) => void;
}

export const TasksView: React.FC<TasksViewProps> = ({
  tasks,
  notes,
  papers,
  onSaveTask,
  onDeleteTask,
  activeProjectFilter,
  onSelectProjectFilter,
}) => {
  const [statusFilter, setStatusFilter] = useState<string>("Tutti");
  const [priorityFilter, setPriorityFilter] = useState<string>("Tutti");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskItem | null>(null);

  // Form state
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [dueDate, setDueDate] = useState(new Date().toISOString().split("T")[0]);
  const [priority, setPriority] = useState<Priority>("media");
  const [status, setStatus] = useState<TaskStatus>("da fare");
  const [project, setProject] = useState<ProjectName>("RFXANK / MHC-II");
  const [linkedNoteId, setLinkedNoteId] = useState<string>("");
  const [linkedPaperId, setLinkedPaperId] = useState<string>("");

  const projectsList: ProjectName[] = [
    "RFXANK / MHC-II",
    "VUS leucemia",
    "HSC biology",
    "Personale",
    "Altro",
  ];

  const handleOpenCreateModal = () => {
    setEditingTask(null);
    setTitle("");
    setDescription("");
    setDueDate(new Date().toISOString().split("T")[0]);
    setPriority("media");
    setStatus("da fare");
    setProject(activeProjectFilter as ProjectName || "RFXANK / MHC-II");
    setLinkedNoteId("");
    setLinkedPaperId("");
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (task: TaskItem) => {
    setEditingTask(task);
    setTitle(task.title);
    setDescription(task.description);
    setDueDate(task.dueDate);
    setPriority(task.priority);
    setStatus(task.status);
    setProject(task.project);
    setLinkedNoteId(task.linkedNoteId || "");
    setLinkedPaperId(task.linkedPaperId || "");
    setIsModalOpen(true);
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onSaveTask({
      id: editingTask ? editingTask.id : `task-${Date.now()}`,
      title: title.trim(),
      description: description.trim(),
      dueDate,
      priority,
      status,
      project,
      linkedNoteId: linkedNoteId || undefined,
      linkedPaperId: linkedPaperId || undefined,
      createdAt: editingTask ? editingTask.createdAt : new Date().toISOString().split("T")[0],
    });

    setIsModalOpen(false);
  };

  const handleToggleStatus = (task: TaskItem) => {
    const nextStatus: TaskStatus =
      task.status === "fatto"
        ? "da fare"
        : task.status === "da fare"
        ? "in corso"
        : "fatto";

    onSaveTask({
      ...task,
      status: nextStatus,
    });
  };

  const filteredTasks = tasks.filter((t) => {
    if (activeProjectFilter && t.project !== activeProjectFilter) return false;
    if (statusFilter === "Aperti" && t.status === "fatto") return false;
    if (statusFilter === "Completati" && t.status !== "fatto") return false;
    if (priorityFilter !== "Tutti" && t.priority !== priorityFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Tagline */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#161B22]/90 rounded-2xl p-6 border border-slate-800/80 shadow-md backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-sky-500/10 border border-sky-500/20 text-sky-400 uppercase tracking-wide">
              Gestione Attività
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white">Task & Progetti</h2>
          <p className="text-xs text-slate-400 mt-0.5 font-medium">
            "Tutto ciò che devi fare, diviso per progetto."
          </p>
        </div>

        <button
          onClick={handleOpenCreateModal}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold shadow-sm transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-slate-950" />
          <span>Nuovo Task</span>
        </button>
      </div>

      {/* Project & Status Filters */}
      <div className="space-y-3">
        {/* Project Tag Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-xs font-semibold text-slate-500 shrink-0">
            Progetti:
          </span>
          <button
            onClick={() => onSelectProjectFilter(null)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
              !activeProjectFilter
                ? "bg-slate-800 text-sky-400 border border-slate-700 shadow-2xs"
                : "bg-[#161B22] text-slate-400 hover:bg-slate-800/60 border border-slate-800"
            }`}
          >
            Tutti i Progetti ({tasks.length})
          </button>
          {projectsList.map((p) => {
            const count = tasks.filter((t) => t.project === p).length;
            const isSelected = activeProjectFilter === p;
            return (
              <button
                key={p}
                onClick={() => onSelectProjectFilter(isSelected ? null : p)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                  isSelected
                    ? "bg-sky-500 text-slate-950 font-bold shadow-2xs"
                    : "bg-[#161B22] text-slate-400 hover:bg-slate-800/60 border border-slate-800"
                }`}
              >
                {p} ({count})
              </button>
            );
          })}
        </div>

        {/* Secondary filters: Status and Priority */}
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-500">Stato:</span>
            {["Tutti", "Aperti", "Completati"].map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium cursor-pointer ${
                  statusFilter === s
                    ? "bg-slate-800 text-sky-400 font-bold border border-slate-700"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {s}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-500">Priorità:</span>
            {["Tutti", "alta", "media", "bassa"].map((p) => (
              <button
                key={p}
                onClick={() => setPriorityFilter(p)}
                className={`px-2.5 py-1 rounded-lg text-xs capitalize cursor-pointer ${
                  priorityFilter === p
                    ? "bg-slate-800 text-sky-400 font-bold border border-slate-700"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Task Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredTasks.length === 0 ? (
          <div className="col-span-2 bg-[#161B22]/90 rounded-2xl border border-slate-800/80 p-12 text-center text-slate-500 text-xs">
            Nessun task trovato con i filtri correnti.
          </div>
        ) : (
          filteredTasks.map((t) => {
            const linkedNote = notes.find((n) => n.id === t.linkedNoteId);
            const linkedPaper = papers.find((p) => p.id === t.linkedPaperId);

            return (
              <div
                key={t.id}
                className={`bg-[#161B22]/90 rounded-2xl border p-5 shadow-md space-y-3 backdrop-blur-md transition-all ${
                  t.status === "fatto"
                    ? "border-slate-800/60 opacity-60 bg-slate-900/30"
                    : "border-slate-800/80 hover:border-slate-700 hover:shadow-lg"
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <button
                      onClick={() => handleToggleStatus(t)}
                      className={`w-5 h-5 rounded-md mt-0.5 border flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
                        t.status === "fatto"
                          ? "bg-emerald-500 border-emerald-500 text-slate-950"
                          : t.status === "in corso"
                          ? "bg-sky-950 border-sky-500 text-sky-400"
                          : "border-slate-600 hover:border-sky-400 text-transparent"
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    </button>

                    <div className="space-y-1">
                      <h4
                        className={`font-bold text-sm ${
                          t.status === "fatto"
                            ? "line-through text-slate-500"
                            : "text-white"
                        }`}
                      >
                        {t.title}
                      </h4>
                      {t.description && (
                        <p className="text-xs text-slate-400 leading-relaxed">
                          {t.description}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => handleOpenEditModal(t)}
                      className="p-1.5 text-slate-400 hover:text-sky-400 rounded-lg cursor-pointer"
                      title="Modifica"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onDeleteTask(t.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg cursor-pointer"
                      title="Elimina"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Metadata badges & Linked items */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/80 text-[11px]">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      {t.project}
                    </span>
                    <span
                      className={`font-bold px-2 py-0.5 rounded-full uppercase text-[10px] ${
                        t.priority === "alta"
                          ? "bg-rose-950/60 text-rose-300 border border-rose-800"
                          : t.priority === "media"
                          ? "bg-amber-950/60 text-amber-300 border border-amber-800"
                          : "bg-slate-800 text-slate-400 border border-slate-700"
                      }`}
                    >
                      {t.priority}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-slate-400 font-medium">
                    <Clock className="w-3 h-3 text-slate-400" />
                    <span>Scadenza: {t.dueDate}</span>
                  </div>
                </div>

                {(linkedNote || linkedPaper) && (
                  <div className="flex items-center gap-2 text-[10px] bg-[#0B0E14] p-2 rounded-lg border border-slate-800 text-slate-400">
                    <Link2 className="w-3 h-3 text-sky-400 shrink-0" />
                    {linkedNote && (
                      <span>
                        Nota correlata: <strong className="text-slate-200">{linkedNote.title}</strong>
                      </span>
                    )}
                    {linkedPaper && (
                      <span>
                        Paper correlato: <strong className="text-slate-200">{linkedPaper.title.slice(0, 30)}...</strong>
                      </span>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Modal Form for Create / Edit Task */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#161B22] rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-700 space-y-4">
            <h3 className="text-base font-bold text-white">
              {editingTask ? "Modifica Task" : "Crea Nuovo Task"}
            </h3>

            <form onSubmit={handleSubmitForm} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Titolo Task *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="es. Analisi FACS su campioni CD34+"
                  className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-sky-500/30"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Descrizione
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Dettagli operativi, controlli o reagenti..."
                  className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Progetto Associato *
                  </label>
                  <select
                    value={project}
                    onChange={(e) => setProject(e.target.value as ProjectName)}
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  >
                    {projectsList.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Scadenza *
                  </label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Priorità
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as Priority)}
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  >
                    <option value="alta">Alta</option>
                    <option value="media">Media</option>
                    <option value="bassa">Bassa</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Stato
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as TaskStatus)}
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  >
                    <option value="da fare">Da fare</option>
                    <option value="in corso">In corso</option>
                    <option value="fatto">Fatto</option>
                  </select>
                </div>
              </div>

              {/* Optional linking */}
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                    Collega Nota (Opzionale)
                  </label>
                  <select
                    value={linkedNoteId}
                    onChange={(e) => setLinkedNoteId(e.target.value)}
                    className="w-full px-3 py-1.5 bg-[#0B0E14] border border-slate-700 rounded-lg text-xs text-white"
                  >
                    <option value="">-- Nessuna --</option>
                    {notes.map((n) => (
                      <option key={n.id} value={n.id}>
                        {n.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                    Collega Paper (Opzionale)
                  </label>
                  <select
                    value={linkedPaperId}
                    onChange={(e) => setLinkedPaperId(e.target.value)}
                    className="w-full px-3 py-1.5 bg-[#0B0E14] border border-slate-700 rounded-lg text-xs text-white"
                  >
                    <option value="">-- Nessuno --</option>
                    {papers.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.title.slice(0, 30)}...
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:bg-slate-800 rounded-xl cursor-pointer"
                >
                  Annulla
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-xl shadow-sm cursor-pointer"
                >
                  {editingTask ? "Salva Modifiche" : "Crea Task"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
