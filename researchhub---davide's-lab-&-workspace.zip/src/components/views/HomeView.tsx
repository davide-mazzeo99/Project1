import React from "react";
import {
  BookOpen,
  CheckSquare,
  Calendar,
  FileText,
  TrendingUp,
  ArrowUpRight,
  ExternalLink,
  ChevronRight,
  Clock,
  Sparkles,
} from "lucide-react";
import { HeroAgentBox } from "../HeroAgentBox";
import {
  TaskItem,
  NoteItem,
  PaperItem,
  CalendarEventItem,
  ProjectCategory,
} from "../../types";

interface HomeViewProps {
  tasks: TaskItem[];
  notes: NoteItem[];
  papers: PaperItem[];
  events: CalendarEventItem[];
  projects: ProjectCategory[];
  onSelectView: (view: string) => void;
  onRefreshData: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  tasks,
  notes,
  papers,
  events,
  projects,
  onSelectView,
  onRefreshData,
}) => {
  const activeTasks = tasks.filter((t) => t.status !== "fatto");
  const todayStr = new Date().toISOString().split("T")[0];
  const todayEvents = events.filter((e) => e.startTime.startsWith(todayStr));

  // Projects task counts
  const getProjectTaskCount = (projName: string) =>
    tasks.filter((t) => t.project === projName).length;

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Hero & AI Agent Interaction Box */}
      <HeroAgentBox onRefreshData={onRefreshData} />

      {/* 2. Top Metric Cards matching the reference image cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Papers Collected */}
        <div className="bg-[#161B22]/90 rounded-2xl p-4 border border-slate-800/80 shadow-md space-y-3 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold">
              <div className="w-8 h-8 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                <BookOpen className="w-4 h-4" />
              </div>
              <span>Paper Raccolti</span>
            </div>
            <span className="flex items-center gap-0.5 text-[11px] font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-800/50 px-2 py-0.5 rounded-full">
              <TrendingUp className="w-3 h-3" />
              +12.6%
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white">{papers.length}</span>
            <span className="text-xs text-slate-500">vs mese scorso</span>
          </div>
          {/* Sparkline Visual */}
          <div className="h-6 flex items-end gap-1">
            {[40, 65, 50, 80, 70, 95, 100].map((h, i) => (
              <div
                key={i}
                className="flex-1 bg-purple-900/40 hover:bg-purple-500 rounded-t transition-colors"
                style={{ height: `${h}%` }}
              />
            ))}
          </div>
        </div>

        {/* Card 2: Active Tasks */}
        <div className="bg-[#161B22]/90 rounded-2xl p-4 border border-slate-800/80 shadow-md space-y-3 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold">
              <div className="w-8 h-8 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
                <CheckSquare className="w-4 h-4" />
              </div>
              <span>Task In Corso</span>
            </div>
            <span className="text-[11px] font-bold text-sky-400 bg-sky-950/40 border border-sky-800/50 px-2 py-0.5 rounded-full">
              {activeTasks.length} Aperti
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white">{activeTasks.length}</span>
            <span className="text-xs text-slate-500">su {tasks.length} totali</span>
          </div>
          <div className="h-6 flex items-end gap-1">
            {[30, 45, 60, 50, 75, 85, 90].map((h, i) => (
              <div
                key={i}
                className="flex-1 bg-sky-900/40 hover:bg-sky-400 rounded-t transition-colors"
                style={{ height: `${h}%` }}
              />
            ))}
          </div>
        </div>

        {/* Card 3: Events Today */}
        <div className="bg-[#161B22]/90 rounded-2xl p-4 border border-slate-800/80 shadow-md space-y-3 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <Calendar className="w-4 h-4" />
              </div>
              <span>Eventi Oggi</span>
            </div>
            <span className="text-[11px] font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-800/50 px-2 py-0.5 rounded-full">
              {todayEvents.length} Programmati
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white">{todayEvents.length}</span>
            <span className="text-xs text-slate-500">Prossimo: {todayEvents[0]?.title ? todayEvents[0].title.slice(0, 15) + "..." : "Nessuno"}</span>
          </div>
          <div className="h-6 flex items-end gap-1">
            {[50, 70, 60, 90, 80, 85, 95].map((h, i) => (
              <div
                key={i}
                className="flex-1 bg-emerald-900/40 hover:bg-emerald-400 rounded-t transition-colors"
                style={{ height: `${h}%` }}
              />
            ))}
          </div>
        </div>

        {/* Card 4: Notes & Lab Entries */}
        <div className="bg-[#161B22]/90 rounded-2xl p-4 border border-slate-800/80 shadow-md space-y-3 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold">
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <FileText className="w-4 h-4" />
              </div>
              <span>Note & Lab Log</span>
            </div>
            <span className="text-[11px] font-bold text-amber-400 bg-amber-950/40 border border-amber-800/50 px-2 py-0.5 rounded-full">
              {notes.length} Archiviti
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white">{notes.length}</span>
            <span className="text-xs text-slate-500">Aggiornato oggi</span>
          </div>
          <div className="h-6 flex items-end gap-1">
            {[60, 40, 70, 85, 90, 75, 95].map((h, i) => (
              <div
                key={i}
                className="flex-1 bg-amber-900/40 hover:bg-amber-400 rounded-t transition-colors"
                style={{ height: `${h}%` }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* 3. Main Dashboard Grid matching reference image */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Recent Papers & Projects */}
        <div className="lg:col-span-2 space-y-6">
          {/* Papers Table matching screenshot */}
          <div className="bg-[#161B22]/90 rounded-2xl border border-slate-800/80 p-5 shadow-md space-y-4 backdrop-blur-md">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-white text-sm">
                  Ultimi Paper in Libreria
                </h3>
                <p className="text-xs text-slate-400">
                  Articoli chiave salvati per la ricerca in Gene Therapy
                </p>
              </div>
              <button
                onClick={() => onSelectView("papers")}
                className="text-xs text-sky-400 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Vedi tutti ({papers.length})</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead>
                  <tr className="border-b border-slate-800 text-[11px] uppercase font-semibold text-slate-500">
                    <th className="py-2.5 px-3">Titolo</th>
                    <th className="py-2.5 px-3">Autori</th>
                    <th className="py-2.5 px-3">Rivista</th>
                    <th className="py-2.5 px-3">Anno</th>
                    <th className="py-2.5 px-3">Stato</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {papers.slice(0, 4).map((paper) => (
                    <tr
                      key={paper.id}
                      className="hover:bg-slate-800/40 transition-colors cursor-pointer"
                      onClick={() => onSelectView("papers")}
                    >
                      <td className="py-3 px-3 font-medium text-white max-w-xs truncate">
                        {paper.title}
                      </td>
                      <td className="py-3 px-3 text-slate-400 truncate max-w-[140px]">
                        {paper.authors}
                      </td>
                      <td className="py-3 px-3 text-slate-300 font-medium">
                        {paper.journal}
                      </td>
                      <td className="py-3 px-3 text-slate-400">{paper.year}</td>
                      <td className="py-3 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            paper.status === "importante"
                              ? "bg-purple-950/60 text-purple-300 border border-purple-800"
                              : paper.status === "letto"
                              ? "bg-emerald-950/60 text-emerald-300 border border-emerald-800"
                              : "bg-amber-950/60 text-amber-300 border border-amber-800"
                          }`}
                        >
                          {paper.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Project Breakdown Cards matching reference screenshot */}
          <div className="bg-[#161B22]/90 rounded-2xl border border-slate-800/80 p-5 shadow-md space-y-4 backdrop-blur-md">
            <h3 className="font-bold text-white text-sm">
              Progetti di Ricerca & Stato Avanzamento
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {projects.map((proj) => {
                const count = getProjectTaskCount(proj.name);
                return (
                  <div
                    key={proj.id}
                    onClick={() => onSelectView("tasks")}
                    className="p-3.5 rounded-xl border border-slate-800 bg-[#0F172A]/60 hover:bg-slate-800/50 hover:border-slate-700 transition-all cursor-pointer space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: proj.accentHex }}
                        />
                        <span className="font-bold text-xs text-white">
                          {proj.name}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 font-medium">
                        {count} task
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 line-clamp-2">
                      {proj.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Today's Agenda & Urgent Tasks matching reference image */}
        <div className="space-y-6">
          {/* Today's Schedule Card */}
          <div className="bg-[#161B22]/90 rounded-2xl border border-slate-800/80 p-5 shadow-md space-y-4 backdrop-blur-md">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <Clock className="w-4 h-4 text-sky-400" />
                <span>Agenda di Oggi</span>
              </h3>
              <button
                onClick={() => onSelectView("calendar")}
                className="text-xs text-sky-400 font-semibold hover:underline"
              >
                Vedi Agenda
              </button>
            </div>

            <div className="space-y-2.5">
              {todayEvents.length === 0 ? (
                <p className="text-xs text-slate-500 italic py-2">
                  Nessun evento in programma per oggi.
                </p>
              ) : (
                todayEvents.map((evt) => (
                  <div
                    key={evt.id}
                    className="p-3 rounded-xl bg-[#0F172A]/70 border border-slate-800 space-y-1"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-white">{evt.title}</span>
                      <span className="text-[10px] font-semibold text-sky-300 bg-sky-950/60 border border-sky-800 px-2 py-0.5 rounded">
                        {evt.startTime.slice(11, 16)} - {evt.endTime.slice(11, 16)}
                      </span>
                    </div>
                    {evt.location && (
                      <p className="text-[11px] text-slate-400">📍 {evt.location}</p>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Urgent & High Priority Tasks Card */}
          <div className="bg-[#161B22]/90 rounded-2xl border border-slate-800/80 p-5 shadow-md space-y-4 backdrop-blur-md">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <CheckSquare className="w-4 h-4 text-sky-400" />
                <span>Task Prioritari</span>
              </h3>
              <button
                onClick={() => onSelectView("tasks")}
                className="text-xs text-sky-400 font-semibold hover:underline"
              >
                Gestisci
              </button>
            </div>

            <div className="space-y-2">
              {activeTasks.slice(0, 4).map((t) => (
                <div
                  key={t.id}
                  onClick={() => onSelectView("tasks")}
                  className="p-3 rounded-xl border border-slate-800/80 bg-[#0F172A]/50 hover:bg-slate-800/50 hover:border-slate-700 transition-colors cursor-pointer space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-xs text-slate-200 line-clamp-1">
                      {t.title}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        t.priority === "alta"
                          ? "bg-rose-950/60 text-rose-300 border border-rose-800"
                          : t.priority === "media"
                          ? "bg-amber-950/60 text-amber-300 border border-amber-800"
                          : "bg-slate-800 text-slate-400 border border-slate-700"
                      }`}
                    >
                      {t.priority}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>{t.project}</span>
                    <span>Scadenza: {t.dueDate}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
