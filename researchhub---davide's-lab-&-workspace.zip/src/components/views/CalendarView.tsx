import React, { useState } from "react";
import {
  Calendar as CalendarIcon,
  Plus,
  Clock,
  MapPin,
  Tag,
  CheckCircle2,
  Trash2,
  Globe,
  Layers,
  ChevronLeft,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { CalendarEventItem, CalendarName, ProjectName } from "../../types";

interface CalendarViewProps {
  events: CalendarEventItem[];
  onSaveEvent: (event: CalendarEventItem) => void;
  onDeleteEvent: (id: string) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  events,
  onSaveEvent,
  onDeleteEvent,
}) => {
  const [viewMode, setViewMode] = useState<"agenda" | "giorno" | "settimana">("agenda");
  const [filterCalendar, setFilterCalendar] = useState<string>("Tutti");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isGoogleConnected, setIsGoogleConnected] = useState(true);

  // Form state
  const [title, setTitle] = useState("");
  const [startTime, setStartTime] = useState(new Date().toISOString().slice(0, 16));
  const [endTime, setEndTime] = useState(new Date().toISOString().slice(0, 16));
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [calendarName, setCalendarName] = useState<CalendarName>("Lab");
  const [project, setProject] = useState<ProjectName>("RFXANK / MHC-II");

  const calendarCategories: CalendarName[] = ["Lab", "Personale", "Seminari", "Esperimenti"];

  const filteredEvents = events.filter((e) => {
    if (filterCalendar !== "Tutti" && e.calendarName !== filterCalendar) return false;
    return true;
  });

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onSaveEvent({
      id: `evt-${Date.now()}`,
      title: title.trim(),
      startTime,
      endTime,
      location: location.trim() || undefined,
      description: description.trim() || undefined,
      calendarName,
      project,
    });

    setTitle("");
    setLocation("");
    setDescription("");
    setIsModalOpen(false);
  };

  const getCalendarBadgeColor = (cal: CalendarName) => {
    switch (cal) {
      case "Lab":
        return "bg-sky-950/60 text-sky-300 border-sky-800";
      case "Personale":
        return "bg-amber-950/60 text-amber-300 border-amber-800";
      case "Seminari":
        return "bg-purple-950/60 text-purple-300 border-purple-800";
      case "Esperimenti":
        return "bg-emerald-950/60 text-emerald-300 border-emerald-800";
      default:
        return "bg-slate-800 text-slate-400 border-slate-700";
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Tagline */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#161B22]/90 rounded-2xl p-6 border border-slate-800/80 shadow-md backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-sky-500/10 border border-sky-500/20 text-sky-400 uppercase tracking-wide">
              Calendario Laboratorio & Personale
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white">Calendario</h2>
          <p className="text-xs text-slate-400 mt-0.5 font-medium">
            "La tua giornata, a colpo d'occhio."
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Google OAuth Status Indicator */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700 text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-semibold text-slate-300">Google Calendar Connesso</span>
          </div>

          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold shadow-sm transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4 text-slate-950" />
            <span>Nuovo Evento</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs & View Selectors */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Calendar Category Filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          <button
            onClick={() => setFilterCalendar("Tutti")}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              filterCalendar === "Tutti"
                ? "bg-slate-800 text-sky-400 border border-slate-700"
                : "bg-[#161B22] text-slate-400 hover:bg-slate-800/60 border border-slate-800"
            }`}
          >
            Tutti i Calendari
          </button>
          {calendarCategories.map((cal) => (
            <button
              key={cal}
              onClick={() => setFilterCalendar(cal)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                filterCalendar === cal
                  ? "bg-sky-500 text-slate-950 font-bold shadow-2xs"
                  : "bg-[#161B22] text-slate-400 hover:bg-slate-800/60 border border-slate-800"
              }`}
            >
              {cal}
            </button>
          ))}
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center bg-slate-800/80 p-1 rounded-xl text-xs font-semibold border border-slate-700/80">
          {(["agenda", "giorno", "settimana"] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setViewMode(mode)}
              className={`px-3 py-1 rounded-lg capitalize transition-all cursor-pointer ${
                viewMode === mode
                  ? "bg-sky-500 text-slate-950 font-bold shadow-2xs"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {/* Main Agenda Event List */}
      <div className="bg-[#161B22]/90 rounded-2xl border border-slate-800/80 p-6 shadow-md space-y-4 backdrop-blur-md">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <Clock className="w-4 h-4 text-sky-400" />
            <span>Prossimi Eventi in Agenda</span>
          </h3>
          <span className="text-xs text-slate-500">
            {filteredEvents.length} eventi trovati
          </span>
        </div>

        {filteredEvents.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-xs">
            Nessun evento in agenda per la combinazione selezionata.
          </div>
        ) : (
          <div className="space-y-3">
            {filteredEvents.map((evt) => (
              <div
                key={evt.id}
                className="p-4 rounded-xl border border-slate-800/80 bg-[#0F172A]/50 hover:border-slate-700 hover:bg-slate-800/40 transition-all flex flex-col md:flex-row md:items-center justify-between gap-3 group"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${getCalendarBadgeColor(
                        evt.calendarName
                      )}`}
                    >
                      {evt.calendarName}
                    </span>
                    {evt.project && (
                      <span className="text-[10px] font-semibold text-slate-400 bg-slate-800 border border-slate-700 px-2 py-0.5 rounded">
                        {evt.project}
                      </span>
                    )}
                  </div>

                  <h4 className="font-bold text-white text-sm">
                    {evt.title}
                  </h4>

                  {evt.description && (
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {evt.description}
                    </p>
                  )}

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1">
                    <span className="flex items-center gap-1 text-slate-300 font-medium">
                      <Clock className="w-3.5 h-3.5 text-sky-400" />
                      {evt.startTime.replace("T", " dalle ")} alle {evt.endTime.slice(11, 16)}
                    </span>
                    {evt.location && (
                      <span className="flex items-center gap-1 text-slate-400">
                        <MapPin className="w-3.5 h-3.5 text-rose-400" />
                        {evt.location}
                      </span>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => onDeleteEvent(evt.id)}
                  className="self-end md:self-center p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer opacity-0 group-hover:opacity-100"
                  title="Elimina Evento"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Event Creation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#161B22] rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-700 space-y-4">
            <h3 className="text-base font-bold text-white">
              Crea Evento Calendario
            </h3>

            <form onSubmit={handleCreateEvent} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Titolo Evento *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="es. Transfezione HEK293T / Riunione Lab"
                  className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-sky-500/30 focus:border-sky-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Inizio *
                  </label>
                  <input
                    type="datetime-local"
                    required
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Fine *
                  </label>
                  <input
                    type="datetime-local"
                    required
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Luogo / Stanza
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="es. Stanza Citometria 204"
                  className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Calendario Origine
                  </label>
                  <select
                    value={calendarName}
                    onChange={(e) => setCalendarName(e.target.value as CalendarName)}
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  >
                    {calendarCategories.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Progetto Associato
                  </label>
                  <select
                    value={project}
                    onChange={(e) => setProject(e.target.value as ProjectName)}
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  >
                    <option value="RFXANK / MHC-II">RFXANK / MHC-II</option>
                    <option value="VUS leucemia">VUS leucemia</option>
                    <option value="HSC biology">HSC biology</option>
                    <option value="Personale">Personale</option>
                    <option value="Altro">Altro</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Descrizione / Note
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Dettagli esperimento o punti all'ordine del giorno..."
                  className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
                >
                  Annulla
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-xl shadow-sm transition-all cursor-pointer"
                >
                  Salva Evento
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
