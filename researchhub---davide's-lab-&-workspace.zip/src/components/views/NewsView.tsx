import React, { useState } from "react";
import {
  Newspaper,
  BookOpen,
  ExternalLink,
  Plus,
  CheckCircle2,
  Search,
  Tag,
  Sparkles,
  Rss,
} from "lucide-react";
import { NewsPublicationItem, PaperItem, ProjectName } from "../../types";

interface NewsViewProps {
  newsItems: NewsPublicationItem[];
  onSavePaper: (paper: PaperItem) => void;
  savedPaperDois: string[];
}

export const NewsView: React.FC<NewsViewProps> = ({
  newsItems,
  onSavePaper,
  savedPaperDois,
}) => {
  const [feedTab, setFeedTab] = useState<"news" | "pubblicazioni">("news");
  const [keywordFilter, setKeywordFilter] = useState<string>("Tutti");
  const [searchQuery, setSearchQuery] = useState("");
  const [addedItemIds, setAddedItemIds] = useState<Record<string, boolean>>({});

  const keywords = ["Tutti", "RFXANK", "HSC", "Prime Editing", "CRISPR", "FDA"];

  const filteredItems = newsItems.filter((item) => {
    if (item.category !== feedTab) return false;
    if (keywordFilter !== "Tutti") {
      const kw = keywordFilter.toLowerCase();
      const text = `${item.title} ${item.summary} ${item.tags.join(" ")}`.toLowerCase();
      if (!text.includes(kw)) return false;
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const text = `${item.title} ${item.summary} ${item.source}`.toLowerCase();
      if (!text.includes(q)) return false;
    }
    return true;
  });

  const handleSaveToLibrary = (item: NewsPublicationItem) => {
    let proj: ProjectName = "RFXANK / MHC-II";
    if (item.tags.includes("HSC") || item.tags.includes("Prime Editing")) {
      proj = "HSC biology";
    }

    onSavePaper({
      id: `paper-news-${Date.now()}`,
      title: item.title,
      authors: item.source,
      journal: item.journal || item.source,
      year: new Date().getFullYear(),
      doi: item.doi,
      url: item.link,
      abstract: item.summary,
      project: proj,
      status: "da leggere",
      personalNotes: `Salvato dal Feed Pubblicazioni & News il ${new Date().toLocaleDateString()}`,
      addedAt: new Date().toISOString().split("T")[0],
    });

    setAddedItemIds((prev) => ({ ...prev, [item.id]: true }));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Tagline */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#161B22]/90 rounded-2xl p-6 border border-slate-800/80 shadow-md backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 uppercase tracking-wide">
              Intelligence & Feed Settoriale
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white">
            News & Pubblicazioni
          </h2>
          <p className="text-xs text-slate-400 mt-0.5 font-medium">
            "Il settore si muove. Tu lo sai prima degli altri."
          </p>
        </div>

        {/* Feed Tab Toggle matching PRD Section 5.6 */}
        <div className="flex items-center bg-[#0B0E14] p-1 rounded-xl border border-slate-800 text-xs font-semibold self-start sm:self-auto">
          <button
            onClick={() => setFeedTab("news")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              feedTab === "news"
                ? "bg-slate-800 text-white shadow-2xs font-bold"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Newspaper className="w-3.5 h-3.5 text-sky-400" />
            <span>News di Settore</span>
          </button>
          <button
            onClick={() => setFeedTab("pubblicazioni")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              feedTab === "pubblicazioni"
                ? "bg-slate-800 text-white shadow-2xs font-bold"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-purple-400" />
            <span>Pubblicazioni</span>
          </button>
        </div>
      </div>

      {/* Keyword Chips & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          <span className="text-xs font-semibold text-slate-500 shrink-0">
            Filtra per Parola Chiave:
          </span>
          {keywords.map((kw) => (
            <button
              key={kw}
              onClick={() => setKeywordFilter(kw)}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                keywordFilter === kw
                  ? "bg-sky-500 text-slate-950 font-bold shadow-2xs"
                  : "bg-[#161B22] text-slate-400 hover:bg-slate-800/60 border border-slate-800"
              }`}
            >
              {kw}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cerca notizie e articoli..."
            className="w-full pl-9 pr-3 py-1.5 bg-[#161B22] border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500/30"
          />
        </div>
      </div>

      {/* Feed Card List */}
      <div className="space-y-4">
        {filteredItems.length === 0 ? (
          <div className="bg-[#161B22]/90 rounded-2xl border border-slate-800/80 p-12 text-center text-slate-500 text-xs">
            Nessun elemento trovato per i filtri correnti.
          </div>
        ) : (
          filteredItems.map((item) => {
            const isAdded = addedItemIds[item.id];
            return (
              <div
                key={item.id}
                className="bg-[#161B22]/90 rounded-2xl border border-slate-800/80 hover:border-slate-700 p-5 shadow-md backdrop-blur-md transition-all space-y-3"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                        {item.source}
                      </span>
                      <span className="text-xs text-slate-400 font-medium">
                        {item.date}
                      </span>
                    </div>

                    <h3 className="font-bold text-white text-base leading-snug">
                      {item.title}
                    </h3>
                  </div>

                  {/* 1-Click Save to Library button */}
                  <button
                    onClick={() => handleSaveToLibrary(item)}
                    disabled={isAdded}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-all shrink-0 ${
                      isAdded
                        ? "bg-emerald-950/60 text-emerald-300 border border-emerald-800"
                        : "bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 border border-sky-500/30"
                    }`}
                  >
                    {isAdded ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>In Libreria</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" />
                        <span>Salva in Libreria</span>
                      </>
                    )}
                  </button>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed bg-[#0B0E14] p-3 rounded-xl border border-slate-800/80">
                  {item.summary}
                </p>

                <div className="flex items-center justify-between text-[11px] pt-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {item.tags.map((t) => (
                      <span
                        key={t}
                        className="text-[10px] font-medium text-slate-400 bg-slate-800 border border-slate-700 px-2 py-0.5 rounded"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>

                  <a
                    href={item.link}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-sky-400 font-semibold hover:underline"
                  >
                    <span>Leggi Articolo Completo</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
