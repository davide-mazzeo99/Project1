import React, { useState } from "react";
import {
  FileText,
  Plus,
  Search,
  Tag,
  Clock,
  Trash2,
  Edit2,
  BookOpen,
  CheckSquare,
  Link2,
} from "lucide-react";
import { NoteItem, ProjectName, TaskItem, PaperItem } from "../../types";

interface NotesViewProps {
  notes: NoteItem[];
  tasks: TaskItem[];
  papers: PaperItem[];
  onSaveNote: (note: NoteItem) => void;
  onDeleteNote: (id: string) => void;
  activeProjectFilter: string | null;
  onSelectProjectFilter: (proj: string | null) => void;
}

export const NotesView: React.FC<NotesViewProps> = ({
  notes,
  tasks,
  papers,
  onSaveNote,
  onDeleteNote,
  activeProjectFilter,
  onSelectProjectFilter,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<NoteItem | null>(null);

  // Form state
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [project, setProject] = useState<ProjectName>("RFXANK / MHC-II");
  const [linkedTaskId, setLinkedTaskId] = useState<string>("");
  const [linkedPaperId, setLinkedPaperId] = useState<string>("");

  const projectsList: ProjectName[] = [
    "RFXANK / MHC-II",
    "VUS leucemia",
    "HSC biology",
    "Personale",
    "Altro",
  ];

  const handleOpenCreate = () => {
    setEditingNote(null);
    setTitle("");
    setContent("");
    setProject((activeProjectFilter as ProjectName) || "RFXANK / MHC-II");
    setLinkedTaskId("");
    setLinkedPaperId("");
    setIsModalOpen(true);
  };

  const handleOpenEdit = (note: NoteItem) => {
    setEditingNote(note);
    setTitle(note.title);
    setContent(note.content);
    setProject(note.project);
    setLinkedTaskId(note.linkedTaskId || "");
    setLinkedPaperId(note.linkedPaperId || "");
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const todayStr = new Date().toISOString().split("T")[0];

    onSaveNote({
      id: editingNote ? editingNote.id : `note-${Date.now()}`,
      title: title.trim(),
      content: content.trim(),
      project,
      createdAt: editingNote ? editingNote.createdAt : todayStr,
      updatedAt: todayStr,
      linkedTaskId: linkedTaskId || undefined,
      linkedPaperId: linkedPaperId || undefined,
    });

    setIsModalOpen(false);
  };

  const filteredNotes = notes.filter((n) => {
    if (activeProjectFilter && n.project !== activeProjectFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        n.title.toLowerCase().includes(q) ||
        n.content.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Tagline */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#161B22]/90 rounded-2xl p-6 border border-slate-800/80 shadow-md backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/10 border border-amber-500/20 text-amber-400 uppercase tracking-wide">
              Quaderno di Laboratorio & Note
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white">Note & Appunti</h2>
          <p className="text-xs text-slate-400 mt-0.5 font-medium">
            "Le idee non si perdono, si archiviano."
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold shadow-sm transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-slate-950" />
          <span>Nuova Nota</span>
        </button>
      </div>

      {/* Filter Bar & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Project Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          <button
            onClick={() => onSelectProjectFilter(null)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
              !activeProjectFilter
                ? "bg-slate-800 text-sky-400 border border-slate-700 shadow-2xs"
                : "bg-[#161B22] text-slate-400 hover:bg-slate-800/60 border border-slate-800"
            }`}
          >
            Tutte ({notes.length})
          </button>
          {projectsList.map((p) => {
            const count = notes.filter((n) => n.project === p).length;
            const isSelected = activeProjectFilter === p;
            return (
              <button
                key={p}
                onClick={() => onSelectProjectFilter(isSelected ? null : p)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                  isSelected
                    ? "bg-sky-500 text-slate-950 font-bold shadow-2xs"
                    : "bg-[#161B22] text-slate-400 hover:bg-slate-800/60 border border-slate-800"
                }`}
              >
                {p} ({count})
              </button>
            );
          })}
        </div>

        {/* Local Search Input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cerca nelle note..."
            className="w-full pl-9 pr-3 py-1.5 bg-[#161B22] border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500/30"
          />
        </div>
      </div>

      {/* Note Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredNotes.length === 0 ? (
          <div className="col-span-3 bg-[#161B22]/90 rounded-2xl border border-slate-800/80 p-12 text-center text-slate-500 text-xs">
            Nessuna nota trovata per i criteri cercati.
          </div>
        ) : (
          filteredNotes.map((note) => {
            const linkedTask = tasks.find((t) => t.id === note.linkedTaskId);
            const linkedPaper = papers.find((p) => p.id === note.linkedPaperId);

            return (
              <div
                key={note.id}
                className="bg-[#161B22]/90 rounded-2xl border border-slate-800/80 hover:border-slate-700 p-5 shadow-md backdrop-blur-md transition-all flex flex-col justify-between space-y-3 group"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                      {note.project}
                    </span>

                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => handleOpenEdit(note)}
                        className="p-1 text-slate-400 hover:text-sky-400 rounded cursor-pointer"
                        title="Modifica"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteNote(note.id)}
                        className="p-1 text-slate-400 hover:text-rose-400 rounded cursor-pointer"
                        title="Elimina"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <h3 className="font-bold text-white text-sm leading-snug">
                    {note.title}
                  </h3>

                  <div className="text-xs text-slate-300 line-clamp-6 whitespace-pre-wrap font-sans leading-relaxed bg-[#0B0E14] p-2.5 rounded-xl border border-slate-800/80">
                    {note.content}
                  </div>
                </div>

                {/* Footer details & Links */}
                <div className="space-y-2 pt-2 border-t border-slate-800/80">
                  <div className="flex items-center justify-between text-[10px] text-slate-500">
                    <span>Creato: {note.createdAt}</span>
                    <span>Modificato: {note.updatedAt}</span>
                  </div>

                  {(linkedTask || linkedPaper) && (
                    <div className="text-[10px] bg-slate-800/80 p-2 rounded-lg border border-slate-700 text-slate-300 space-y-1">
                      {linkedTask && (
                        <p className="truncate">
                          🔗 Task: <strong className="text-white">{linkedTask.title}</strong>
                        </p>
                      )}
                      {linkedPaper && (
                        <p className="truncate">
                          📚 Paper: <strong className="text-white">{linkedPaper.title.slice(0, 30)}...</strong>
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal Editor for Note */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#161B22] rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-700 space-y-4">
            <h3 className="text-base font-bold text-white">
              {editingNote ? "Modifica Nota" : "Crea Nuova Nota di Laboratorio"}
            </h3>

            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Titolo Nota *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="es. Protocollo elettroporazione RNP Cas9"
                  className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-sky-500/30"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Progetto Associato *
                </label>
                <select
                  value={project}
                  onChange={(e) => setProject(e.target.value as ProjectName)}
                  className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                >
                  {projectsList.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Contenuto (Supporta Markdown o testo libero) *
                </label>
                <textarea
                  rows={8}
                  required
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Scrivi appunti di laboratorio, protocolli, risultati FACS o riflessioni..."
                  className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white font-mono leading-relaxed"
                />
              </div>

              {/* Linking */}
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                    Collega Task (Opzionale)
                  </label>
                  <select
                    value={linkedTaskId}
                    onChange={(e) => setLinkedTaskId(e.target.value)}
                    className="w-full px-3 py-1.5 bg-[#0B0E14] border border-slate-700 rounded-lg text-xs text-white"
                  >
                    <option value="">-- Nessun Task --</option>
                    {tasks.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                    Collega Paper (Opzionale)
                  </label>
                  <select
                    value={linkedPaperId}
                    onChange={(e) => setLinkedPaperId(e.target.value)}
                    className="w-full px-3 py-1.5 bg-[#0B0E14] border border-slate-700 rounded-lg text-xs text-white"
                  >
                    <option value="">-- Nessun Paper --</option>
                    {papers.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.title.slice(0, 30)}...
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:bg-slate-800 rounded-xl cursor-pointer"
                >
                  Annulla
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-xl shadow-sm cursor-pointer"
                >
                  {editingNote ? "Salva Modifiche" : "Crea Nota"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
