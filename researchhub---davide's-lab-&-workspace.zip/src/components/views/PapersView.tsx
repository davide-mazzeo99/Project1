import React, { useState } from "react";
import {
  BookOpen,
  Plus,
  Search,
  Download,
  ExternalLink,
  Sparkles,
  Tag,
  Loader2,
  Trash2,
  Edit3,
  CheckCircle2,
  Bookmark,
  FileText,
} from "lucide-react";
import { PaperItem, PaperStatus, ProjectName } from "../../types";

interface PapersViewProps {
  papers: PaperItem[];
  onSavePaper: (paper: PaperItem) => void;
  onDeletePaper: (id: string) => void;
  activeProjectFilter: string | null;
  onSelectProjectFilter: (proj: string | null) => void;
}

export const PapersView: React.FC<PapersViewProps> = ({
  papers,
  onSavePaper,
  onDeletePaper,
  activeProjectFilter,
  onSelectProjectFilter,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("Tutti");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPaper, setEditingPaper] = useState<PaperItem | null>(null);

  // DOI Lookup state
  const [doiLookupQuery, setDoiLookupQuery] = useState("");
  const [isFetchingDoi, setIsFetchingDoi] = useState(false);
  const [lookupMessage, setLookupMessage] = useState<string | null>(null);

  // Form state
  const [title, setTitle] = useState("");
  const [authors, setAuthors] = useState("");
  const [journal, setJournal] = useState("");
  const [year, setYear] = useState<number>(new Date().getFullYear());
  const [doi, setDoi] = useState("");
  const [url, setUrl] = useState("");
  const [abstract, setAbstract] = useState("");
  const [project, setProject] = useState<ProjectName>("RFXANK / MHC-II");
  const [status, setStatus] = useState<PaperStatus>("da leggere");
  const [personalNotes, setPersonalNotes] = useState("");

  const projectsList: ProjectName[] = [
    "RFXANK / MHC-II",
    "VUS leucemia",
    "HSC biology",
    "Personale",
    "Altro",
  ];

  const handleOpenCreateModal = () => {
    setEditingPaper(null);
    setTitle("");
    setAuthors("");
    setJournal("");
    setYear(new Date().getFullYear());
    setDoi("");
    setUrl("");
    setAbstract("");
    setProject((activeProjectFilter as ProjectName) || "RFXANK / MHC-II");
    setStatus("da leggere");
    setPersonalNotes("");
    setDoiLookupQuery("");
    setLookupMessage(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (paper: PaperItem) => {
    setEditingPaper(paper);
    setTitle(paper.title);
    setAuthors(paper.authors);
    setJournal(paper.journal);
    setYear(paper.year);
    setDoi(paper.doi || "");
    setUrl(paper.url || "");
    setAbstract(paper.abstract);
    setProject(paper.project);
    setStatus(paper.status);
    setPersonalNotes(paper.personalNotes || "");
    setLookupMessage(null);
    setIsModalOpen(true);
  };

  // Auto-compilation of Metadata via /api/pubmed (PubMed / CrossRef lookup!)
  const handleFetchDoiMetadata = async () => {
    if (!doiLookupQuery.trim()) return;
    setIsFetchingDoi(true);
    setLookupMessage(null);

    try {
      const res = await fetch(`/api/pubmed?query=${encodeURIComponent(doiLookupQuery.trim())}`);
      if (!res.ok) throw new Error("Recupero metadati fallito");
      const data = await res.json();

      if (data) {
        setTitle(data.title || "");
        setAuthors(data.authors || "");
        setJournal(data.journal || "");
        setYear(data.year || new Date().getFullYear());
        setDoi(data.doi || doiLookupQuery);
        setUrl(data.url || `https://doi.org/${data.doi || doiLookupQuery}`);
        if (data.abstract) setAbstract(data.abstract);
        setLookupMessage("Metadati compilati con successo da PubMed/CrossRef!");
      }
    } catch (err: any) {
      console.error(err);
      setLookupMessage("Impossibile recuperare metadati per questo DOI. Inserire manualmente.");
    } finally {
      setIsFetchingDoi(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onSavePaper({
      id: editingPaper ? editingPaper.id : `paper-${Date.now()}`,
      title: title.trim(),
      authors: authors.trim() || "Autori vari",
      journal: journal.trim() || "Journal Scientifico",
      year: Number(year) || new Date().getFullYear(),
      doi: doi.trim() || undefined,
      url: url.trim() || undefined,
      abstract: abstract.trim(),
      project,
      status,
      personalNotes: personalNotes.trim(),
      addedAt: editingPaper ? editingPaper.addedAt : new Date().toISOString().split("T")[0],
    });

    setIsModalOpen(false);
  };

  const filteredPapers = papers.filter((p) => {
    if (activeProjectFilter && p.project !== activeProjectFilter) return false;
    if (statusFilter !== "Tutti" && p.status !== statusFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        p.title.toLowerCase().includes(q) ||
        p.authors.toLowerCase().includes(q) ||
        p.journal.toLowerCase().includes(q) ||
        p.abstract.toLowerCase().includes(q) ||
        (p.doi && p.doi.toLowerCase().includes(q))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Tagline */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#161B22]/90 rounded-2xl p-6 border border-slate-800/80 shadow-md backdrop-blur-md">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-purple-500/10 border border-purple-500/20 text-purple-400 uppercase tracking-wide">
              Libreria Scientifica
            </span>
          </div>
          <h2 className="text-2xl font-bold text-white">Paper & Articoli</h2>
          <p className="text-xs text-slate-400 mt-0.5 font-medium">
            "La tua libreria, sempre a portata di mano."
          </p>
        </div>

        <button
          onClick={handleOpenCreateModal}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold shadow-sm transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-slate-950" />
          <span>Aggiungi Paper</span>
        </button>
      </div>

      {/* Filters & Local Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Project & Status Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onSelectProjectFilter(null)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer ${
              !activeProjectFilter
                ? "bg-slate-800 text-sky-400 border border-slate-700"
                : "bg-[#161B22] text-slate-400 border border-slate-800"
            }`}
          >
            Tutti ({papers.length})
          </button>
          {projectsList.map((p) => (
            <button
              key={p}
              onClick={() =>
                onSelectProjectFilter(activeProjectFilter === p ? null : p)
              }
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer ${
                activeProjectFilter === p
                  ? "bg-sky-500 text-slate-950 font-bold"
                  : "bg-[#161B22] text-slate-400 border border-slate-800"
              }`}
            >
              {p}
            </button>
          ))}

          <div className="h-4 w-px bg-slate-800 mx-1" />

          {["Tutti", "importante", "da leggere", "letto"].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-2.5 py-1 rounded-lg text-xs capitalize cursor-pointer ${
                statusFilter === st
                  ? "bg-purple-950/60 text-purple-300 border border-purple-800 font-bold"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cerca per titolo, autore, DOI..."
            className="w-full pl-9 pr-3 py-1.5 bg-[#161B22] border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500/30"
          />
        </div>
      </div>

      {/* Papers Table & Cards View */}
      <div className="space-y-4">
        {filteredPapers.length === 0 ? (
          <div className="bg-[#161B22]/90 rounded-2xl border border-slate-800/80 p-12 text-center text-slate-500 text-xs">
            Nessun paper corrisponde ai filtri selezionati.
          </div>
        ) : (
          filteredPapers.map((paper) => (
            <div
              key={paper.id}
              className="bg-[#161B22]/90 rounded-2xl border border-slate-800/80 hover:border-slate-700 p-5 shadow-md backdrop-blur-md transition-all space-y-3 group"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        paper.status === "importante"
                          ? "bg-purple-950/60 text-purple-300 border border-purple-800"
                          : paper.status === "letto"
                          ? "bg-emerald-950/60 text-emerald-300 border border-emerald-800"
                          : "bg-amber-950/60 text-amber-300 border border-amber-800"
                      }`}
                    >
                      {paper.status}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-300 bg-slate-800 border border-slate-700 px-2 py-0.5 rounded">
                      {paper.project}
                    </span>
                    <span className="text-xs text-slate-400 font-medium">
                      {paper.journal} ({paper.year})
                    </span>
                  </div>

                  <h3 className="font-bold text-white text-sm leading-snug">
                    {paper.title}
                  </h3>

                  <p className="text-xs text-slate-400 font-medium">
                    Autori: {paper.authors}
                  </p>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => handleOpenEditModal(paper)}
                    className="p-1.5 text-slate-400 hover:text-sky-400 rounded-lg cursor-pointer"
                    title="Modifica Metadati"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeletePaper(paper.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg cursor-pointer"
                    title="Elimina"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Abstract */}
              {paper.abstract && (
                <div className="bg-[#0B0E14] p-3 rounded-xl border border-slate-800/80 text-xs text-slate-300 leading-relaxed">
                  <span className="font-semibold text-white">Abstract: </span>
                  {paper.abstract}
                </div>
              )}

              {/* Personal Notes */}
              {paper.personalNotes && (
                <div className="bg-purple-950/30 p-2.5 rounded-xl border border-purple-800/40 text-xs text-purple-300 font-medium">
                  💬 Note personali: {paper.personalNotes}
                </div>
              )}

              {/* Links & DOI */}
              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-800/80">
                <div className="flex items-center gap-3">
                  {paper.doi && (
                    <span className="font-mono text-slate-400">
                      DOI: {paper.doi}
                    </span>
                  )}
                  {paper.url && (
                    <a
                      href={paper.url}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1 text-sky-400 font-semibold hover:underline"
                    >
                      <span>Vedi Articolo Esterno</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
                <span>Aggiunto il: {paper.addedAt}</span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal for Creating/Editing Paper with DOI Auto-Fetcher */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#161B22] rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-700 space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-base font-bold text-white">
              {editingPaper ? "Modifica Paper" : "Aggiungi Paper in Libreria"}
            </h3>

            {/* DOI / PubMed Auto Fetch Box */}
            {!editingPaper && (
              <div className="bg-gradient-to-r from-purple-950/40 to-slate-900 p-3.5 rounded-xl border border-purple-800/50 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-purple-300">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>Auto-compilazione da DOI o PubMed ID</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={doiLookupQuery}
                    onChange={(e) => setDoiLookupQuery(e.target.value)}
                    placeholder="Incolla DOI (es. 10.1038/s41587-023-01980-6) o PubMed ID"
                    className="flex-1 px-3 py-1.5 bg-[#0B0E14] border border-purple-800/40 rounded-lg text-xs text-white"
                  />
                  <button
                    type="button"
                    onClick={handleFetchDoiMetadata}
                    disabled={isFetchingDoi || !doiLookupQuery.trim()}
                    className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs rounded-lg cursor-pointer transition-colors flex items-center gap-1 shrink-0"
                  >
                    {isFetchingDoi ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      "Recupera Metadati"
                    )}
                  </button>
                </div>
                {lookupMessage && (
                  <p className="text-[11px] font-semibold text-purple-300">
                    {lookupMessage}
                  </p>
                )}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Titolo Articolo *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="es. Correction of RFXANK deficiency..."
                  className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-sky-500/30"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Autori
                  </label>
                  <input
                    type="text"
                    value={authors}
                    onChange={(e) => setAuthors(e.target.value)}
                    placeholder="es. Smith A., Rossi G., et al."
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Rivista / Journal
                  </label>
                  <input
                    type="text"
                    value={journal}
                    onChange={(e) => setJournal(e.target.value)}
                    placeholder="es. Nature Biotechnology"
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Anno
                  </label>
                  <input
                    type="number"
                    value={year}
                    onChange={(e) => setYear(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Progetto *
                  </label>
                  <select
                    value={project}
                    onChange={(e) => setProject(e.target.value as ProjectName)}
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  >
                    {projectsList.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Stato Lettura
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as PaperStatus)}
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  >
                    <option value="da leggere">Da leggere</option>
                    <option value="letto">Letto</option>
                    <option value="importante">Importante</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    DOI
                  </label>
                  <input
                    type="text"
                    value={doi}
                    onChange={(e) => setDoi(e.target.value)}
                    placeholder="10.1038/..."
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Link URL
                  </label>
                  <input
                    type="url"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="https://doi.org/..."
                    className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Abstract
                </label>
                <textarea
                  rows={3}
                  value={abstract}
                  onChange={(e) => setAbstract(e.target.value)}
                  placeholder="Riassunto del paper..."
                  className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Note Personali
                </label>
                <textarea
                  rows={2}
                  value={personalNotes}
                  onChange={(e) => setPersonalNotes(e.target.value)}
                  placeholder="Considerazioni per il tuo PhD, punti chiave o controlli da replicare..."
                  className="w-full px-3 py-2 bg-[#0B0E14] border border-slate-700 rounded-xl text-xs text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:bg-slate-800 rounded-xl cursor-pointer"
                >
                  Annulla
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-xl shadow-sm cursor-pointer"
                >
                  {editingPaper ? "Salva Modifiche" : "Salva Paper"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
