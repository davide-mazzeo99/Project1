import React from "react";
import {
  Search,
  Bell,
  HelpCircle,
  Moon,
  Sparkles,
  ChevronDown,
  Calendar as CalendarIcon,
} from "lucide-react";

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenAiDrawer: () => void;
  onSelectView: (view: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  searchQuery,
  onSearchChange,
  onOpenAiDrawer,
  onSelectView,
}) => {
  return (
    <header className="h-16 border-b border-slate-800/80 bg-[#161B22]/80 backdrop-blur-md px-6 flex items-center justify-between sticky top-0 z-20">
      {/* Global Search Bar matching screenshot */}
      <div className="relative w-96">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Cerca paper, task, note, sequenze..."
          className="w-full pl-10 pr-12 py-2 bg-[#0F172A] hover:bg-slate-900 focus:bg-[#0B0E14] border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500/30 focus:border-sky-500 transition-all"
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-0.5 pointer-events-none text-[10px] font-mono font-semibold text-slate-400 bg-slate-800 border border-slate-700 px-1.5 py-0.5 rounded shadow-2xs">
          <span>⌘</span>
          <span>K</span>
        </div>
      </div>

      {/* Right Action Icons & Profile */}
      <div className="flex items-center gap-3">
        {/* Date Selector Badge matching screenshot */}
        <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs text-slate-300 font-medium">
          <CalendarIcon className="w-3.5 h-3.5 text-sky-400" />
          <span>Oggi, 30 Luglio 2026</span>
        </div>

        {/* AI Quick Agent Trigger */}
        <button
          onClick={onOpenAiDrawer}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-500/10 text-sky-400 hover:bg-sky-500/20 border border-sky-500/30 text-xs font-medium transition-colors cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5 text-sky-400" />
          <span>Chiedi all'Agente AI</span>
        </button>

        <div className="h-4 w-px bg-slate-800 mx-1" />

        {/* Action Buttons */}
        <button
          onClick={() => alert("Nessuna nuova notifica nel laboratorio.")}
          className="relative p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
          title="Notifiche"
        >
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-sky-400 ring-2 ring-[#161B22]" />
        </button>

        <button
          onClick={() => onSelectView("news")}
          className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
          title="Aiuto & Documentazione"
        >
          <HelpCircle className="w-4 h-4" />
        </button>

        <div className="h-4 w-px bg-slate-800 mx-1" />

        {/* User Profile matching reference screenshot */}
        <div className="flex items-center gap-2.5 pl-1 cursor-pointer group">
          <div className="relative">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-sky-500 via-indigo-500 to-purple-500 flex items-center justify-center text-white text-xs font-bold shadow-sm">
              DM
            </div>
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-[#161B22]" />
          </div>
          <div className="hidden sm:block text-left">
            <p className="text-xs font-semibold text-slate-200 leading-tight">
              Davide Mazzeo
            </p>
            <p className="text-[10px] text-slate-400 font-medium">
              PhD Researcher
            </p>
          </div>
        </div>
      </div>
    </header>
  );
};
