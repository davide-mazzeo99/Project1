import React from "react";
import {
  LayoutDashboard,
  Calendar,
  CheckSquare,
  FileText,
  BookOpen,
  Newspaper,
  FlaskConical,
  HardDrive,
  Plus,
  Sparkles,
} from "lucide-react";
import { ProjectCategory } from "../types";

interface SidebarProps {
  currentView: string;
  onSelectView: (view: string) => void;
  projects: ProjectCategory[];
  activeProjectFilter: string | null;
  onSelectProjectFilter: (projectName: string | null) => void;
  tasksCount: number;
  papersCount: number;
  onOpenAiDrawer: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onSelectView,
  projects,
  activeProjectFilter,
  onSelectProjectFilter,
  tasksCount,
  papersCount,
  onOpenAiDrawer,
}) => {
  const navItems = [
    { id: "home", label: "Overview", icon: LayoutDashboard },
    { id: "calendar", label: "Calendario", icon: Calendar },
    { id: "tasks", label: "Task", icon: CheckSquare, badge: tasksCount },
    { id: "notes", label: "Note", icon: FileText },
    { id: "papers", label: "Paper", icon: BookOpen, badge: papersCount },
    { id: "news", label: "News & Pubblicazioni", icon: Newspaper },
  ];

  return (
    <aside className="w-64 bg-[#161B22]/80 border-r border-slate-800/80 backdrop-blur-md flex flex-col justify-between shrink-0 select-none text-slate-300 min-h-screen">
      <div className="p-4 space-y-6">
        {/* Brand Logo & Title matching screenshot */}
        <div className="flex items-center gap-3 px-2 py-1">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-sky-500/20 accent-glow">
            <FlaskConical className="w-5 h-5 text-sky-100" />
          </div>
          <div>
            <h1 className="font-bold text-white text-lg leading-tight tracking-tight">
              ResearchHub
            </h1>
            <p className="text-xs font-medium text-slate-400">
              Davide's PhD Workspace
            </p>
          </div>
        </div>

        {/* AI Agent Quick Trigger Button */}
        <button
          onClick={onOpenAiDrawer}
          className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-sky-500/20 via-indigo-500/20 to-purple-500/20 border border-sky-500/30 text-sky-300 hover:text-white shadow-sm hover:border-sky-400/50 transition-all group cursor-pointer"
        >
          <div className="flex items-center gap-2.5 font-medium text-xs">
            <Sparkles className="w-4 h-4 text-sky-400 animate-pulse" />
            <span>Agente AI Assistant</span>
          </div>
          <span className="text-[10px] bg-sky-500/30 border border-sky-400/30 px-2 py-0.5 rounded text-sky-200 group-hover:bg-sky-500/40 transition-colors">
            Chiedi
          </span>
        </button>

        {/* Navigation Section */}
        <nav className="space-y-1">
          <p className="px-3 text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
            Menu Principale
          </p>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectView(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
                  isActive
                    ? "bg-slate-800/90 text-sky-400 border border-slate-700/80 shadow-sm shadow-sky-500/10 font-semibold"
                    : "text-slate-400 hover:bg-slate-800/40 hover:text-slate-200"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 ${
                      isActive ? "text-sky-400" : "text-slate-500"
                    }`}
                  />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && item.badge > 0 && (
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                      isActive
                        ? "bg-sky-500/20 text-sky-300 border border-sky-500/30"
                        : "bg-slate-800 text-slate-400"
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Collections / Progetti Section matching reference screenshot */}
        <div className="space-y-2 pt-2 border-t border-slate-800/80">
          <div className="flex items-center justify-between px-3">
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
              Progetti & Tag
            </p>
            {activeProjectFilter && (
              <button
                onClick={() => onSelectProjectFilter(null)}
                className="text-[11px] text-sky-400 hover:underline cursor-pointer"
              >
                Reset
              </button>
            )}
          </div>

          <div className="space-y-1">
            {projects.map((proj) => {
              const isSelected = activeProjectFilter === proj.name;
              return (
                <button
                  key={proj.id}
                  onClick={() =>
                    onSelectProjectFilter(isSelected ? null : proj.name)
                  }
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    isSelected
                      ? "bg-slate-800 text-white font-semibold border border-slate-700"
                      : "text-slate-400 hover:bg-slate-800/40 hover:text-slate-200"
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0 shadow-xs"
                      style={{ backgroundColor: proj.accentHex }}
                    />
                    <span className="truncate">{proj.name}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Storage Footer matching reference image (45.6 GB / 100 GB) */}
      <div className="p-4 border-t border-slate-800/80 bg-[#0F172A]/50">
        <div className="bg-[#161B22]/90 rounded-xl p-3 border border-slate-800/80 space-y-2">
          <div className="flex items-center justify-between text-xs font-medium text-slate-400">
            <div className="flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5 text-sky-400" />
              <span>Storage Lab</span>
            </div>
            <span className="text-sky-400 font-bold text-[11px]">45%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-sky-400 h-full rounded-full transition-all duration-500 accent-glow"
              style={{ width: "45%" }}
            />
          </div>
          <p className="text-[10px] text-slate-500">
            45.6 GB di 100 GB in uso
          </p>
        </div>
      </div>
    </aside>
  );
};
