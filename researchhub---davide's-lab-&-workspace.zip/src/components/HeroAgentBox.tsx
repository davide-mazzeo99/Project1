import React, { useState } from "react";
import {
  Sparkles,
  Send,
  Loader2,
  CheckCircle2,
  PlusCircle,
  RefreshCw,
  ChevronDown,
  Calendar,
  CheckSquare,
  FileText,
  BookOpen,
} from "lucide-react";
import { AgentMessage, AgentAction } from "../types";
import {
  saveTask,
  saveNote,
  saveCalendarEvent,
  getTasks,
  getNotes,
  getPapers,
  getCalendarEvents,
  getSelectedHeadlineIndex,
  setSelectedHeadlineIndex,
} from "../lib/storage";

const HERO_HEADLINES = [
  {
    title: "Il tuo laboratorio, in un'unica schermata.",
    subtitle: "Task, note, paper e calendario — tutto dove serve, quando serve.",
  },
  {
    title: "Meno tempo a cercare. Più tempo a scoprire.",
    subtitle: "La tua ricerca merita la stessa precisione del tuo editing genico.",
  },
  {
    title: "Dove finisce il caos, inizia la scienza.",
    subtitle: "Una dashboard che tiene insieme la tua vita e i tuoi progetti — così tu puoi concentrarti sui risultati.",
  },
  {
    title: "Ogni progetto ha la sua sequenza. Qui trovi la tua.",
    subtitle: "Calendario, task, note e paper allineati — come un editing ben riuscito.",
  },
  {
    title: "La tua ricerca, editata per la massima efficienza.",
    subtitle: "Un unico punto di controllo per la tua vita da ricercatore.",
  },
];

interface HeroAgentBoxProps {
  onRefreshData?: () => void;
}

export const HeroAgentBox: React.FC<HeroAgentBoxProps> = ({ onRefreshData }) => {
  const [headlineIdx, setHeadlineIdx] = useState<number>(() =>
    getSelectedHeadlineIndex()
  );
  const [showHeadlineMenu, setShowHeadlineMenu] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<AgentMessage[]>([]);
  const [executedActions, setExecutedActions] = useState<Record<string, boolean>>({});

  const currentHeadline = HERO_HEADLINES[headlineIdx] || HERO_HEADLINES[0];

  const handleSelectHeadline = (idx: number) => {
    setHeadlineIdx(idx);
    setSelectedHeadlineIndex(idx);
    setShowHeadlineMenu(false);
  };

  const handleSendPrompt = async (textToSend?: string) => {
    const finalPrompt = (textToSend || prompt).trim();
    if (!finalPrompt || isLoading) return;

    const userMsgId = `user-${Date.now()}`;
    const newMessages: AgentMessage[] = [
      ...messages,
      {
        id: userMsgId,
        sender: "user",
        text: finalPrompt,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      },
    ];

    setMessages(newMessages);
    setPrompt("");
    setIsLoading(true);

    try {
      // Gather real live context from storage
      const context = {
        tasks: getTasks(),
        notes: getNotes(),
        papers: getPapers(),
        events: getCalendarEvents(),
        currentDate: new Date().toISOString().split("T")[0],
      };

      const res = await fetch("/api/agent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: finalPrompt, context }),
      });

      if (!res.ok) {
        throw new Error("Errore di risposta dal server AI");
      }

      const data = await res.json();
      const assistantMsgId = `asst-${Date.now()}`;

      setMessages((prev) => [
        ...prev,
        {
          id: assistantMsgId,
          sender: "assistant",
          text: data.reply || "Ho verificato le informazioni per te.",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          action: data.action,
        },
      ]);
    } catch (err: any) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: `asst-err-${Date.now()}`,
          sender: "assistant",
          text: `Si è verificato un errore nel contattare l'agente AI: ${err.message}. Puoi comunque procedere manualmente.`,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleExecuteAction = (msgId: string, action: AgentAction) => {
    try {
      if (action.type === "CREATE_TASK") {
        saveTask({
          id: `task-ai-${Date.now()}`,
          title: action.data.title || "Nuovo task da Agente AI",
          description: action.data.description || "",
          dueDate: action.data.dueDate || new Date().toISOString().split("T")[0],
          priority: action.data.priority || "media",
          status: "da fare",
          project: action.data.project || "RFXANK / MHC-II",
          createdAt: new Date().toISOString().split("T")[0],
        });
      } else if (action.type === "CREATE_NOTE") {
        saveNote({
          id: `note-ai-${Date.now()}`,
          title: action.data.title || "Nuova Nota AI",
          content: action.data.content || "",
          project: action.data.project || "RFXANK / MHC-II",
          createdAt: new Date().toISOString().split("T")[0],
          updatedAt: new Date().toISOString().split("T")[0],
        });
      } else if (action.type === "CREATE_EVENT") {
        saveCalendarEvent({
          id: `evt-ai-${Date.now()}`,
          title: action.data.title || "Evento AI",
          startTime: action.data.startTime || new Date().toISOString().slice(0, 16),
          endTime: action.data.endTime || new Date().toISOString().slice(0, 16),
          location: action.data.location || "Lab",
          calendarName: action.data.calendarName || "Lab",
          project: "RFXANK / MHC-II",
        });
      }

      setExecutedActions((prev) => ({ ...prev, [msgId]: true }));
      if (onRefreshData) onRefreshData();
    } catch (e) {
      console.error("Failed to execute action:", e);
    }
  };

  return (
    <div className="bg-[#161B22]/90 rounded-2xl border border-slate-800/80 p-6 shadow-xl space-y-5 backdrop-blur-md">
      {/* 2.1 Hero / Hook Section with Option Selector */}
      <div className="relative flex flex-col md:flex-row md:items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-sky-500/10 border border-sky-500/20 text-sky-400 tracking-wide uppercase">
              Command Center
            </span>
            <span className="text-xs text-slate-400">• PhD Gene & Cell Therapy</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight leading-tight">
            "{currentHeadline.title}"
          </h2>
          <p className="text-sm text-slate-400 mt-1 font-normal max-w-2xl">
            {currentHeadline.subtitle}
          </p>
        </div>

        {/* Headline Preset Dropdown Toggle */}
        <div className="relative shrink-0">
          <button
            onClick={() => setShowHeadlineMenu(!showHeadlineMenu)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-slate-300 bg-slate-800/90 border border-slate-700 shadow-2xs hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5 text-sky-400" />
            <span>Cambia Hook ({headlineIdx + 1}/5)</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {showHeadlineMenu && (
            <div className="absolute right-0 mt-2 w-72 bg-[#161B22] rounded-xl shadow-2xl border border-slate-700 p-2 z-30 space-y-1">
              <p className="text-[10px] uppercase font-bold text-slate-400 px-2 py-1">
                Scegli Headline per la tua Dashboard:
              </p>
              {HERO_HEADLINES.map((h, i) => (
                <button
                  key={i}
                  onClick={() => handleSelectHeadline(i)}
                  className={`w-full text-left p-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    headlineIdx === i
                      ? "bg-sky-500/20 text-sky-400 font-semibold border border-sky-500/30"
                      : "text-slate-300 hover:bg-slate-800"
                  }`}
                >
                  <p className="line-clamp-1">{i + 1}. {h.title}</p>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 2.2 Microcopy & AI Agent Interaction Box positioned RIGHT BELOW hook */}
      <div className="bg-[#0F172A]/90 rounded-xl p-4 border border-sky-500/30 shadow-md space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-sky-500 flex items-center justify-center text-slate-950 font-bold shadow-2xs accent-glow">
              <Sparkles className="w-4 h-4 text-slate-950" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white">
                Agente AI — Assistente di Ricerca
              </h3>
              <p className="text-[10px] text-slate-400">
                Connesso a agenda, task, note e paper di Davide
              </p>
            </div>
          </div>
          {isLoading && (
            <div className="flex items-center gap-1.5 text-xs text-sky-400 font-medium animate-pulse">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>Sto controllando...</span>
            </div>
          )}
        </div>

        {/* Input Field & Button matching Section 2.2 PRD */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendPrompt();
          }}
          className="flex items-center gap-2"
        >
          <div className="relative flex-1">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Chiedimi qualcosa — un'agenda, un task, un riassunto..."
              disabled={isLoading}
              className="w-full px-4 py-2.5 bg-[#0B0E14] hover:bg-slate-900 focus:bg-slate-950 border border-slate-700/80 focus:border-sky-500 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500/30 transition-all"
            />
          </div>
          <button
            type="submit"
            disabled={isLoading || !prompt.trim()}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-slate-950 text-xs font-bold shadow-sm shadow-sky-500/30 transition-all cursor-pointer shrink-0"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
            ) : (
              <Send className="w-4 h-4 text-slate-950" />
            )}
            <span>Chiedi</span>
          </button>
        </form>

        {/* Suggested Quick Prompts */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-[10px] font-semibold text-slate-400">
            Esempi rapidi:
          </span>
          {[
            "Cosa ho in agenda oggi?",
            "Crea un task per domani su RFXANK",
            "Riassumi l'ultimo paper su CDH7",
            "Che note ho su FANCD2P2?",
          ].map((suggestion, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSendPrompt(suggestion)}
              className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-sky-500/10 hover:text-sky-400 hover:border-sky-500/40 border border-slate-700 text-slate-300 transition-colors cursor-pointer"
            >
              {suggestion}
            </button>
          ))}
        </div>

        {/* AI Agent Recent Conversation Output */}
        {messages.length > 0 && (
          <div className="mt-4 pt-3 border-t border-slate-800 space-y-3 max-h-80 overflow-y-auto pr-1 custom-scrollbar">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`p-3 rounded-xl text-xs space-y-2 ${
                  msg.sender === "user"
                    ? "bg-slate-800 text-slate-200 ml-8 border border-slate-700"
                    : "bg-sky-950/40 border border-sky-800/50 text-sky-100 mr-4"
                }`}
              >
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span className="font-semibold text-sky-400">
                    {msg.sender === "user" ? "Davide" : "Agente AI"}
                  </span>
                  <span>{msg.timestamp}</span>
                </div>
                <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>

                {/* Optional Agent Executable Action Card */}
                {msg.action && (
                  <div className="mt-2 p-2.5 bg-[#0B0E14] rounded-lg border border-sky-500/40 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <PlusCircle className="w-4 h-4 text-sky-400" />
                      <div>
                        <p className="text-xs font-bold text-white">
                          Azione suggerita: {msg.action.type.replace("_", " ")}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          {msg.action.data.title || "Dettagli azione"}
                        </p>
                      </div>
                    </div>

                    {executedActions[msg.id] ? (
                      <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950/50 border border-emerald-800 px-2.5 py-1 rounded-md">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Eseguito!
                      </span>
                    ) : (
                      <button
                        onClick={() => handleExecuteAction(msg.id, msg.action!)}
                        className="px-3 py-1 rounded-md bg-sky-500 hover:bg-sky-400 text-slate-950 text-[11px] font-bold cursor-pointer transition-colors shadow-2xs"
                      >
                        Esegui Ora
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
